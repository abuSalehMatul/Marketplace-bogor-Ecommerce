<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class SellerPlan extends Model
{
    public $timestamps = false;
}
