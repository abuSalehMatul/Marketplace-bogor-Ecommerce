<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductCategory extends Model
{
    public $timestamps = false;

    // public function matchbuyer(){
    // 	 return $this->hasMany(Buyer::class,'business_sector');
    // }
}
