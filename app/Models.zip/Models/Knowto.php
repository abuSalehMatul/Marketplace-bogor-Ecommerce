<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Knowto extends Model
{
    public $timestamps = false;
}
