<?php $__env->startSection('title','Edit'); ?>
<?php $__env->startSection('content'); ?>

<div class="content-page">
  <!-- Start content -->
  <div class="content">
    <div class="container">
      <div class="row">
        <div class="col-xs-12">
          <div class="page-title-box">
            <h4 class="page-title"><?php echo e($header); ?></h4>
            <div class="clearfix"><a href="<?php echo e(url($url)); ?>" class="pull-right btn btn-info btn-sm"><i class="fa fa-backward"></i> Back</a></div>
          </div>
        </div>
      </div>
      <!-- end row -->
      <div class="row">
        <div class="col-sm-12">
          <div class="card-box">
            <?php echo e(Form::open(array('route' => array('advertisement.update', $row->id),'class' =>'form-horizontal','method' =>'PATCH','files'=>true))); ?>

            <div class="row">
              <div class="form-group">
                <div class="col-sm-12">
                  <label for="">Banner Image</label>
                  <input type="file" name="banner_image" class="form-control" onchange="loadFile(event, 'banner')" accept="image/*">
                  <div class="text-danger"><?php echo e($errors->first('banner_image')); ?></div>
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-12">
                  <img src="<?php echo e(asset($row->banner_image)); ?>" class="img-thumbnail img-responsive" alt="" id="banner" >
                </div>
              </div>
            </div>
            <div class="row">
              <div class="form-group">
                <div class="col-md-12">
                  <button class="btn btn-primary btn-sm" type="submit">Save</button>
                </div>
              </div>
            </div>
            <?php echo Form::close(); ?>

          </div>
        </div>
      </div>
    </div>
  </div> <!-- container -->
</div> <!-- content -->
<?php $__env->stopSection(); ?>


<?php $__env->startPush('footerscript'); ?>
<script>
  var loadFile = function (event, imgid) {
    var output = document.getElementById(imgid);
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>