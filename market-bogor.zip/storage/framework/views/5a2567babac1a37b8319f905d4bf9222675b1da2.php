<?php $__env->startSection('content'); ?>
<div class="tp-page-head">
  <!-- page header -->
  <div class="container">
    <div class="row">
      <div class="col-md-offset-2 col-md-8">
        <div class="page-header text-center">
          <h1>Thank You for Registration!</h1>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="section-space80">
  <!-- Feature Blog Start -->
  <div class="container ">
    <div class="row">
      <div class="col-md-12">
       <section class="form-box">

        <div class="row">
          <div class="col-md-12 text-center">
            <p class="lead">
              You are successfully registered with us.
            </p>
            <p>
              Please Click The Logging Button?
            </p>
          </div>
        </div>

      </section>

    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>