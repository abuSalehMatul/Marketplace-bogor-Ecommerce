<?php
    $mytype=($search['type']=='seller-in-africa')?'Africa':'Global';
?>
<?php $__env->startSection('title',"Best $catrow->category_name Products in $mytype"); ?>
<?php $__env->startPush('headerscript'); ?>
<style>
.radio-inline input[type="radio"]{
    margin-top: 0px;
        width: 20px;
    height: 20px;
}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="tp-page-head">
    <!-- page header -->
    <div class="container">
        <div class="row">
            <div class="col-md-offset-2 col-md-8">
                <div class="page-header text-center">
                    <h1>Best <?php echo e($catrow->category_name); ?> Products <?php echo e($mytype); ?></h1>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="filter-box">
    <div class="container">
        <div class="row filter-form">
            <form action="<?php echo e(url('search')); ?>" method="get">
                 <div class="col-md-3">
                    <?php echo Form::select('for',['companies'=>'Companies','products'=>'Products'], old('for',$search['for']),  ['class'=>'form-control ', 'required'=>'']); ?>

                </div>
                <div class="col-md-3">
                    <?php echo Form::select('search',['seller-in-africa'=>'Seller In Africa','seller-in-global'=>'Seller In Globel','3'=>'All'], old('search',$search['type']),  ['class'=>'form-control ', 'required'=>'']); ?>

                </div>
                <div class="col-md-3">
                    <?php echo Form::select('category',[''=>'--Select Category--']+CommonClass::CategoryList1(), old('product',$catrow->category_slug),  ['class'=>'form-control ', 'required'=>'']); ?>

                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary btn-block">Search</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="section-space80">
    <!-- Feature Blog Start -->
    <div class="container ">
        <div class="row">
            <div class="col-md-3 left-sidebar">
                <div class="col-md-12 widget widget-category">
                    <!-- widget -->
                    <div class="well-box">
                        <h2 class="widget-title">Categories</h2>
                        <ul class="listnone angle-double-right sidebarlist">
                             <?php 
                            $for=$search['for'];
                            $search=$search['type'];
                            ?>
                            <?php $__currentLoopData = CommonClass::category(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catrow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(url("search?for=$for&search=$search&category=$catrow->category_slug")); ?>"><?php echo e($catrow->category_name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="well-box">
                        <h3 class="widget-title">Download Diretory</h3>
                        <ul class="listnone angle-double-right sidebarlist">
                           <?php $__currentLoopData = CommonClass::GetSector(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <li><a href="<?php echo e(url("sectors-directory/$crow->sector_slug")); ?>"><?php echo e($crow->sector_name); ?></a></li>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <?php $__currentLoopData = CommonClass::GetCountry(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <li><a href="<?php echo e(url("countries-directory/$crow->country_slug")); ?>"><?php echo e($crow->country_name); ?> Directory</a></li>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </ul>
                   </div>
                </div>
            </div>
           
            <div class="col-sm-6">
                <div class="form-group">
                    <label class="radio-inline">
                      <input type="radio" name="product_type" value="all" checked=""><span class="label label-success">All</span>
                  </label>
                  <label class="radio-inline">
                      <input type="radio" name="product_type" value="1"><span class="label label-primary">New</span>
                  </label>
                  <label class="radio-inline">
                      <input type="radio" name="product_type" value="2"><span class="label label-danger">Used</span>
                  </label>
              </div>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="vendor-box-list type<?php echo e($row->product_type); ?>">
                    <!-- vendor list -->
                    <div class="row">
                        <div class="col-md-5 no-right-pd">
                            <div class="vendor-image">
                                <!-- venue pic -->
                                <a href="<?php echo e(url("seller-product/$row->product_slug/$row->unique_code")); ?>"><img src="<?php echo e(asset($row->featured_image)); ?>" alt="wedding venue" class="img-responsive"></a>
                            </div>
                        </div>
                        <!-- /.venue pic -->
                        <div class="col-md-7 no-left-pd">
                            <!-- venue details -->
                            <div class="vendor-list-details">
                                <div class="caption">
                                    <!-- caption -->
                                    <h2><a href="<?php echo e(url("seller-product/$row->product_slug/$row->unique_code")); ?>" class="title"><?php echo e($row->product_name); ?></a></h2>
                                    <p><?php echo e($row->short_description); ?></p>
                                </div>
                                <!-- /.caption -->
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="vendor-price">
                                <a href="<?php echo e(url("seller-product/$row->product_slug/$row->unique_code")); ?>" class="btn btn-primary btn-sm">View Detail</a>&nbsp;&nbsp;
                                <a href="<?php echo e(url("seller-product/$row->product_slug/$row->unique_code")); ?>" class="btn btn-primary btn-sm">Send Mail</a>
                                <span class="pull-right">For <?php echo e(($row->post_type==1)?'Buy':'Sell'); ?></span>
                            </div>
                        </div>

                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-md-3">
                <div class="filter-sidebar">
                    <?php echo $__env->make('layout.sidebanner', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
        <?php echo $__env->make('layout.bottomad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('footerscript'); ?>
<script>
    $('input[name=product_type]').click(function(){
        if($(this).val()==1){
            $(".type1").show();
            $(".type2").hide();
        }
        else if($(this).val()==2){
            $(".type2").show();
            $(".type1").hide();
        }
        else{
            $(".type2,.type1").show();
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>