<?php $__env->startSection('title','Seller List'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-page">
  <div class="content">
    <div class="container">
       <form action="<?php echo e(url('admin/subscribersendmessage')); ?>" method="POST">
        <?php echo csrf_field(); ?>
           <div class="form-group">
                <label for="message">Message</label>
                
                <textarea  class="form-control" id="message" name="message" required>

                </textarea>
                <input type="submit"  class="form-control btn btn-success" value="Send Message">
            </div>
       </form>
    </div>
  </div>
</div>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>