<?php $__env->startSection('title','Partner_add'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-page">
  <!-- Start content -->
  <div class="content">
    <div class="container">
        
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

      <form action="<?php echo e(url('admin/addpartner')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="exampleFormControlInput1">Name of the Partner</label>
                <input type="text" name="name" class="form-control" id="exampleFormControlInput1" placeholder="ABC company" required>
            </div>
            <div class="form-group">
                <label for="exampleFormControlInput1">url of the Partner</label>
                <input type="text" name="url" class="form-control" id="exampleFormControlInput1" placeholder="https://salehmatul.com" required>
            </div>
            <div class="form-group">
                <label for="exampleFormControlFile1">Thumnile Image of The Partner</label>
                <input type="file" name="image" class="form-control-file" id="exampleFormControlFile1" required>
            </div>
          
            <div class="form-group">
                <label for="exampleFormControlTextarea1">Description</label>
                <textarea class="form-control" name="description" id="exampleFormControlTextarea1" rows="6" required></textarea>
            </div>
            <div class="form-group">
                <input type="submit" class="form-control btn btn-info" value="Add the partner">
            </div>
        </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>