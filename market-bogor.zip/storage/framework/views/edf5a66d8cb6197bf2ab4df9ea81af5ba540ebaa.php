
<?php $__env->startSection('title','Manage My Profile'); ?>
<?php $__env->startPush('headerscript'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('webtheme/css/sidebar.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<?php 
$user=Auth::user();
$seller=$user->seller;
?>
<div class="tp-dashboard-head">
    <!-- page header -->
    <div class="container">
        <div class="row">
            <div class="col-md-12 profile-header">
                <div class="profile-pic col-md-2"><img src="images/profile-dashbaord.png" alt=""></div>
                <div class="profile-info col-md-9">
                    <h1 class="profile-title"><?php echo e($seller->first_name); ?><small>Welcome Back Seller</small></h1>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /.page header -->

<div class="main-container">
    <div class="container">
        <div class="row">
            <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="col-md-9">
                <div class="row">
                   <div class="well-box">
                       <form action="<?php echo e(url('seller/updateprofile')); ?>" method="post" >
                        <?php echo csrf_field(); ?>
                        <h2>My Profile</h2>
                        <!-- Text input-->
                        <?php if(Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo Session::get('success'); ?>

                        </div>
                        <?php endif; ?>
                        <div class="form-group">
                            <label>Username: <span>*</span></label>
                            <input type="text" name="username" value="<?php echo e(old('username',$user->email)); ?>" class="form-control" required="">
                            <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>First Name: <span>*</span></label>
                                    <input type="text" name="first_name" value="<?php echo e(old('first_name',$row->first_name)); ?>" class="form-control" required="">
                                    <span class="text-danger"><?php echo e($errors->first('first_name')); ?></span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Last Name: <span>*</span></label>
                                    <input type="text" name="last_name" value="<?php echo e(old('last_name',$row->last_name)); ?>" class="form-control" required="">
                                    <span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-md-6">
                            <label>Instant Type: <span>*</span></label>
                            <?php echo Form::select('instant_type',['1'=>'WhatsApp','2'=>'Skype','3'=>'WeChat'], old('instant_type',$row->instant_type),  ['class'=>'form-control']); ?>

                            <span class="text-danger"><?php echo e($errors->first('instant_type')); ?></span>
                            </div>
                            <div class="col-md-6">
                            <label>Instant ID: <span>*</span></label>
                            <input type="text" name="instant_id" value="<?php echo e(old('instant_id',$row->instant_id)); ?>" class="form-control"  required="">
                            <span class="text-danger"><?php echo e($errors->first('instant_id')); ?></span>
                        </div>
                    </div>
                        <div class="form-group">
                            <label>Company Name: <span>*</span></label>
                            <input type="text" name="company_name" value="<?php echo e(old('company_name',$row->company_name)); ?>" class="form-control" required="">
                            <span class="text-danger"><?php echo e($errors->first('company_name')); ?></span>
                        </div>
                        <!-- Text input-->
                        <div class="form-group">
                            <label>Business Sector: <span>*</span></label>
                            <?php echo Form::select('business_sector',[''=>'-Business Sector-']+ CommonClass::CategoryList(), old('business_sector',$row->business_sector),  ['class'=>'form-control','required']); ?>

                            <span class="text-danger"><?php echo e($errors->first('business_sector')); ?></span>
                        </div>

                        <div class="form-group">
                            <label>Status of Company: <span>*</span></label>
                            <?php echo Form::select('company_status',[''=>'Status of Company','2'=>'Manufacturer','3'=>'Exporter'], old('company_status',$row->company_status),  ['class'=>'form-control','required']); ?>


                            <span class="text-danger"><?php echo e($errors->first('company_status')); ?></span>
                        </div>
                        
                        <div class="form-group">
                            <label>Contact Number: <span>*</span></label>
                            <input type="text" name="contact_number" value="<?php echo e(old('contact_number',$row->contact_number)); ?>" class="form-control" placeholder="Contact Number" required="">
                            <span class="text-danger"><?php echo e($errors->first('contact_number')); ?></span>
                        </div>
                        <div class="form-group">
                            <label>Website:</label>
                            <input type="text" name="website" value="<?php echo e(old('website',$row->website)); ?>" class="form-control" placeholder="Website (eg: www.domain.com)">
                            <span class="text-danger"><?php echo e($errors->first('website')); ?></span>
                        </div>
                        <div class="form-group">
                            <label>Address Line1: <span>*</span></label>
                            <input type="text" name="address1" value="<?php echo e(old('address1',$row->address1)); ?>" class="form-control" placeholder="Address Line1" required="">
                            <span class="text-danger"><?php echo e($errors->first('address1')); ?></span>
                        </div>

                        <div class="form-group">
                            <label>Address Line2: <span>*</span></label>
                            <input type="text" name="address2" value="<?php echo e(old('address2',$row->address2)); ?>" class="form-control" placeholder="Address Line2" required="">
                            <span class="text-danger"><?php echo e($errors->first('address2')); ?></span>
                        </div>
                        <div class="form-group">
                            <label>City: <span>*</span></label>
                            <input type="text" name="city" value="<?php echo e(old('city',$row->city)); ?>" class="form-control" placeholder="City" required="">
                            <span class="text-danger"><?php echo e($errors->first('city')); ?></span>
                        </div>
                        <div class="form-group">
                            <label>State: <span>*</span></label>
                            <input type="text" name="state" value="<?php echo e(old('state',$row->state)); ?>" class="form-control" placeholder="State" required="">
                            <span class="text-danger"><?php echo e($errors->first('state')); ?></span>
                        </div>

                        <div class="form-group">
                            <label>Postal/Zip code: <span>*</span></label>
                            <input type="text" name="postal" value="<?php echo e(old('postal',$row->postal)); ?>" class="form-control" placeholder="Postal/Zip code" required="">
                            <span class="text-danger"><?php echo e($errors->first('postal')); ?></span>
                        </div>

                        <div class="form-group">
                            <label>Country: <span>*</span></label>
                            <?php echo Form::select('country',[''=>'-Select Country-']+ CommonClass::CountryList(), old('country',$row->country), ['class'=>'form-control']); ?>

                            <span class="text-danger"><?php echo e($errors->first('country')); ?></span>
                        </div>
                        <div class="form-group">
                            <label>Sell In: <span>*</span> </label>

                            <label class="radio-inline">
                                <input type="radio" name="sell_in" id="Radios1" value="1" <?php echo e(($row->sell_in==1)?"checked":''); ?> required="" >
                                Africa
                            </label>
                            <label class="radio-inline">
                                <input type="radio" name="sell_in" id="Radios2" value="2" <?php echo e(($row->sell_in==2)?"checked":''); ?> required="">
                                Global
                            </label>
                            <span class="text-danger"><?php echo e($errors->first('sell_in')); ?></span>
                            <!-- Button -->
                        </div>
                        <div class="row">
                            <div class="form-group">
                                <button name="submit" class="pull-right btn btn-primary btn-sm">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('footerscript'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>