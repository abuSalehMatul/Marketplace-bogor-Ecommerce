<?php $__env->startSection('title','Fronted_Control'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-page">
  <div class="content">
    <div class="container">
        <div class="card" style="width: 18rem;">
            <div class="card-body">
                <h3>website pictures</h3>
                <img class="card-img-top" src="..." alt="Card image cap">
                <img class="card-img-top" src="..." alt="Card image cap">
                <img class="card-img-top" src="..." alt="Card image cap">
            </div>
           
            <div class="card-body">
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            </div>
        </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>