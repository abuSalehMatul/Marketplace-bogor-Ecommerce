
<?php $__env->startSection('title',"Dashboard - Seller"); ?>
<?php $__env->startPush('headerscript'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('webtheme/css/sidebar.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<?php 
$user=Auth::user();
$seller=$user->seller;
?>
<div class="tp-dashboard-head">
    <!-- page header -->
    <div class="container">
        <div class="row">
            <div class="col-md-12 profile-header">
                <div class="profile-pic col-md-2"><img src="images/profile-dashbaord.png" alt=""></div>
                <div class="profile-info col-md-9">
                    <h1 class="profile-title"><?php echo e($seller->first_name); ?><small>Welcome Back memeber</small></h1>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /.page header -->

<div class="main-container">
    <div class="container webdash">

        <div class="row">
            <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="col-md-9">
                <div class="row form-group">
                    <div class="col-sm-4">
                        <div class="box box-info">
                            <h3>Total Enquiry</h3>
                            <p><b><i class="fa fa-inbox"></i> <?php echo e(DashClass::SellerEnquiry($seller->id)); ?></b></p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="box box-primary">
                            <h3>Total Products</h3>
                            <p><b><i class="fa fa-ship"></i> <?php echo e(DashClass::SellerProduct($seller->id)); ?></b></p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="box box-success">
                            <h3>Total Visitors</h3>
                            <p><b><i class="fa fa-users"></i> <?php echo e(DashClass::SellerVisitor($seller->id)); ?></b></p>
                        </div>
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col-sm-12">
                        <div id="columnchart_material" style="height: 300px;"></div>
                    </div>
                </div>
                <?php if(!$plans->isEmpty()): ?>
                <div class="row">
                    <div class="col-sm-12">
                        <h2>Purchased Plans</h2>
                        <table class="table">
                            <thead>
                                <th>Invoice No</th>
                                <th>Purchase Plan</th>
                                <th>Purchase Price</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Plan Status</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($prow->invoice_no); ?></td>
                                    <td><?php echo e($prow->sellerplan->plan_name); ?></td>
                                    <td><?php echo e($prow->purchase_price); ?></td>
                                    <td><?php echo e(date('d M, Y', strtotime($prow->start_date))); ?></td>
                                    <td><?php echo e(date('d M, Y', strtotime($prow->end_date))); ?></td>
                                     <td><?php echo ($prow->plan_status==1)?"<label class='label label-success'>Active</label>":"<label class='label label-danger'>Inactive</label>"; ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>
                <div class="row">
                    <div class="pricing-container">
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        if($loop->iteration==2){
                            $class="pricing-box-top";
                            $btn="btn-primary";
                        }
                        else{
                            $class="pricing-box-regualr";
                            $btn="btn-default";
                        }
                        ?>
                        <div class="col-md-4 pricing-box <?php echo e($class); ?>">
                            <div class="well-box">
                                <h4 class="price-title"><?php echo e($row->plan_name); ?></h4>
                                <h1 class="price-plan"><span class="dollor-sign">$</span><?php echo e($row->charge); ?><span class="permonth">/ year</span></h1>
                                <p><?php echo e($row->description); ?></p>
                                <button type="button" class="btn <?php echo e($btn); ?> btn-sm" onclick="planModal(<?php echo e($row); ?>)">Select Plan</button>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title" id="plan_name"></h4>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(url('seller/purchase-seller-plan')); ?>" method="post">
            <?php echo csrf_field(); ?>
        <input type="hidden" name="plantype" id="plantype">
        <table class="table">
            <tr>
                <th id="price"></th>
            </tr>
            <tr>
                <th>For 1 Year</th>
            </tr>
        </table>
        <button type="submit" class="btn btn-primary">Pay Now</button>
    </form>
      </div>
    </div>

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('headerscript'); ?>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Month', 'Enquiry', 'Visitors'],
          <?php for($iM =1;$iM<=12;$iM++): ?>
          ["<?php echo e(date("M", strtotime("$iM/12/10"))); ?>", <?php echo e(DashClass::SellerEnqMonth($seller->id,$iM)); ?>, <?php echo e(DashClass::SellerVisitorMonth($seller->id,$iM)); ?>],
          <?php endfor; ?>
        ]);

        var options = {
          chart: {
            title: 'Month wise Performance',
            subtitle: '',
          }
        };

        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>
<script>
    function planModal(data){
        $("#myModal").modal()
        $("#plan_name").text(data['plan_name']+" Plan")
        $("#price").text("$"+data['charge'])
        $("#plantype").val(data['id'])
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>