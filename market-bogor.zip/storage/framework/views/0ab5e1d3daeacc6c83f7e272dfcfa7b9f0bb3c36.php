<div class="row">
                <div class="col-sm-12 " id="footercarosil">
                    <div class="carousel-inner">
                    <?php $__currentLoopData = CommonClass::Banner(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <div class="item <?php echo e(($loop->iteration==1)?'active':''); ?>">
                        <img style="width: 100%; height: 90px;" src="<?php echo e(asset($brow->banner_image)); ?>">
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div> 
                </div>
            </div>