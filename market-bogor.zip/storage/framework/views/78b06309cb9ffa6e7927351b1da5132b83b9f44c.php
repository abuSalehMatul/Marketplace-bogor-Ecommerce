<?php $__env->startPush('headerscript'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="tp-page-head">
    <!-- page header -->
    <div class="container">
        <div class="row">
            <div class="col-md-offset-2 col-md-8">
                <div class="page-header text-center">
                    <h1><?php echo e($sellerproduct->product_name); ?></h1>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="section-space80">
    <!-- Feature Blog Start -->
    <div class="container">
        <div class="row">
            <div class="col-sm-9">
                <div class="cardbox">
                    <h2 class="widget-title">Seller wanted to <?php echo e(($sellerproduct->post_type==1)?"Buy":"Sell"); ?></h2>
                    <h4 class="post-title"><?php echo e($sellerproduct->product_name); ?></h4>
                    <div class="post-meta"> <span class="date-meta">ON <a href="#"><?php echo e(date('d F, Y', strtotime($sellerproduct->created_at))); ?></a> /</span> <span class="admin-meta">BY <a href="#"><?php echo e($sellerproduct->first_name); ?></a> /</span> <span class="tag-meta">IN <?php echo e("$sellerproduct->state, $sellerproduct->country_name"); ?></span> </div>
                    <div>
                        <?php echo $sellerproduct->description; ?>

                    </div>
                </div>
                <br>
                <div class="side-box" id="inquiry">
                    <h2>Send Enquiry to Seller</h2>
                    <p>Fill in your details and send e-mail to seller.</p>
                    <form class="">
                        <!-- Text input-->
                        <div class="form-group">
                            <label class="control-label" for="name-one">Name:<span class="required">*</span></label>
                            <div class="">
                                <input id="name-one" name="name-one" type="text" placeholder="Name" class="form-control input-md" required="">
                            </div>
                        </div>
                        <!-- Text input-->
                        <div class="form-group">
                            <label class="control-label" for="phone">Phone:<span class="required">*</span></label>
                            <div class="">
                                <input id="phone" name="phone" type="text" placeholder="Phone" class="form-control input-md" required="">
                                <span class="help-block"> </span> </div>
                            </div>
                            <!-- Text input-->
                            <div class="form-group">
                                <label class="control-label" for="email-one">E-Mail:<span class="required">*</span></label>
                                <div class="">
                                    <input id="email-one" name="email-one" type="text" placeholder="E-Mail" class="form-control input-md" required="">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="email-one">Message<span class="required">*</span></label>
                                <div class="">
                                    <textarea name="" class="form-control"></textarea>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <button name="submit" class="btn btn-primary btn-lg btn-block">Send Enquiry now</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="filter-sidebar">
                       <?php echo $__env->make('layout.sidebanner', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>