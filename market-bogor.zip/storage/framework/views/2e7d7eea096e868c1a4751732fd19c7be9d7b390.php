<?php $__env->startPush('headerscript'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('webtheme/css/sidebar.css')); ?>">
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
<?php 
$user=Auth::user();
$seller=$user->seller;
?>
<div class="tp-dashboard-head">
    <!-- page header -->
    <div class="container">
        <div class="row">
            <div class="col-md-12 profile-header">
                <div class="profile-pic col-md-2"><img src="images/profile-dashbaord.png" alt=""></div>
                <div class="profile-info col-md-9">
                    <h1 class="profile-title"><?php echo e($seller->first_name); ?><small>Welcome Back memeber</small></h1>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /.page header -->

<div class="main-container">
    <div class="container">
        <div class="row">
            <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="col-md-9">
                <div class="row">
                    <div class="row pricing-container">
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        if($loop->iteration==2){
                            $class="pricing-box-top";
                            $btn="btn-primary";
                        }
                        else{
                            $class="pricing-box-regualr";
                            $btn="btn-default";
                        }
                        ?>
                        <div class="col-md-4 pricing-box <?php echo e($class); ?>">
                            <div class="well-box">
                                <h4 class="price-title"><?php echo e($row->plan_name); ?></h4>
                                <h1 class="price-plan"><span class="dollor-sign">$</span><?php echo e($row->charge); ?><span class="permonth">/ year</span></h1>
                                <p><?php echo e($row->description); ?></p>
                                <a href="#" class="btn <?php echo e($btn); ?> btn-sm">Select Plan</a>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>