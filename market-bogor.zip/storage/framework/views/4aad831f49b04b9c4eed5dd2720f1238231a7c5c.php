<?php $__env->startSection('title',"Buy, Sell Products, Download Africa Directory"); ?>
<?php $__env->startPush('headerscript'); ?>
<style>
    .bg-greyb{
    background: #9caebba3;
}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

<div class="slider-bg">
    <!-- slider start-->
    <div id="slider" class="owl-carousel owl-theme slider">
        <div class="item"><img src="<?php echo e(asset('webtheme/images/banner/1.jpg')); ?>" alt="Wedding couple just married"></div>
        <div class="item"><img src="<?php echo e(asset('webtheme/images/banner/2.jpg')); ?>" alt="Wedding couple just married"></div>
        <div class="item"><img src="<?php echo e(asset('webtheme/images/banner/1.jpg')); ?>" alt="Wedding couple just married"></div>
    </div>
    <div class="find-section">
        <!-- Find search section-->
        <div class="container">
            <div class="row">
                <div class="col-md-offset-1 col-md-10 finder-block">
                    <div class="finder-caption">
                        <h1>Find your perfect Product</h1>
                        <p>Over <strong>1200+ Products</strong> for you &amp; Find the perfect &amp; save value.</p>
                    </div>
                    <div class="finderform">
                        <form action="<?php echo e(url("search")); ?>">
                            <div class="row">
                               <div class="col-md-3">
                                <?php echo Form::select('for',['companies'=>'Companies','products'=>'Products'], old('for'),  ['class'=>'form-control ', 'required'=>'']); ?>

                            </div>
                                <div class="form-group col-md-3">
                                    <select name="search" class="form-control" required="">
                                        <option value="">Select a Vendor</option>
                                        <option value="seller-in-africa">Seller in Africa</option>
                                        <option value="seller-in-global">Seller in Global</option>
                                        <option value="buyer-in-africa">Buyer in Africa</option>
                                        <option value="buyer-in-africa">Buyer in Global</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <?php echo Form::select('category',[''=>'-Select Category-'] + CommonClass::CategoryList1(), old('category'), ['class'=>'form-control','required']); ?>

                                </div>
                                <div class="form-group col-md-2">
                                    <button type="submit" class="btn btn-primary btn-lg btn-block">Search</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.Find search section-->
</div>
<div class="">
    <div class="container">
            <div class="row">
                <div class="col-md-6 couple-block sellerhomebox">
                    <div class="row">
                        <div class="col-sm-3">
                            <img src="<?php echo e(asset('webtheme/images/vendor-done.svg')); ?>" alt="" style="height: 50px">
                        </div>
                        <div class="col-sm-9">
                            <h2>Are you a supplier ?</h2>
                            
                              <a href="<?php echo e(url('seller-register')); ?>" class="btn btn-primary">Join as Supplier</a> </div>
                        </div>
                    </div>
                    <div class="col-md-6 couple-block buyerhomebox">
                    <div class="row">
                        <div class="col-sm-3">
                            <img src="<?php echo e(asset('webtheme/images/list.svg')); ?>" alt="" style="height: 50px">
                        </div>
                        <div class="col-sm-9">
                            <h2>Are you a Buyer ?</h2>
                              <a href="<?php echo e(url('buyer-register')); ?>" class="btn btn-primary">Join as Supplier</a> </div>
                        </div>
                    </div>
            </div>
        </div>
</div>
<!-- slider end-->
<div class="section-space40">
    <!-- Feature Blog Start -->
    <div class="container">
       <div class="row">
            <div class="col-md-12">
                <div class="section-title mb60 text-center table-responsive">
                    <h1>Featured <strong>Product</strong>, You Are Looking For </h1>
                </div>
            </div>
        </div>
        <div class="row ">
                <div class="col-md-12 tp-testimonial">
                    <div id="productcaro" class="owl-carousel owl-theme mytesto">
                        <?php $__currentLoopData = CommonClass::products()->take(20); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item testimonial-block">
                            <div class="couple-pic"><a href="<?php echo e(url("seller-product/$pro->product_slug/$pro->unique_code")); ?>"><img src="<?php echo e(asset($pro->featured_image)); ?>" alt="" class="img-responsive" ></a></div>

                            <div class="couple-info">
                                <div class="name"><a href="<?php echo e(url("seller-product/$pro->product_slug/$pro->unique_code")); ?>"><?php echo e($pro->product_name); ?></a></div>
                            </div>
                            <div class="bottom-sec">
                                <div class="name"><a  href="<?php echo e(url("seller-product/$pro->product_slug/$pro->unique_code")); ?>" class="btn btn-primary btn-sm" type="">Request Now</a></div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
            </div>
            
        </div>
    </div>
</div>
<!-- Feature Blog End -->
<div class="section-space40">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title mb60 text-center table-responsive">
                    <h1>Browse Industries by <strong>Categories</strong></h1>
                </div>
            </div>
        </div>
        <div class="row ">
            <div class="col-md-12">
                <ul class="check-circle broweseul">
                    <?php $__currentLoopData = CommonClass::category(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catrow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="bg-white section-space20"><a href="<?php echo e(url("search?for=companies&search=seller-in-africa&category=$catrow->category_slug")); ?>"><?php echo e($catrow->category_name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            
        </div>
       
    </div>
</div>
<div class="section-space40">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                    <div class="section-title mb60 text-center">
                        <h1>Download Industries/Countries Directory</h1>
                    </div>
                </div>
        </div>
        <div class="row">
            <div class="col-sm-4">
                <h2>Industry wise directory</h2>
                <ul class="dir-ul">
                   <?php $__currentLoopData = CommonClass::GetSector(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <li><a href="<?php echo e(url("sectors-directory/$crow->sector_slug")); ?>"><img src="<?php echo e(asset($crow->image)); ?>" width="20"> <?php echo e($crow->sector_name); ?></a></li>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="col-sm-8">
                <h2>Country wise directory</h2>
                <ul class="dir-ul li32">
                   <?php $__currentLoopData = CommonClass::GetCountry(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <li><a href="<?php echo e(url("countries-directory/$crow->country_slug")); ?>"><img src="<?php echo e(asset($crow->country_flag)); ?>" width="20"> <?php echo e($crow->country_name); ?> Directory</a></li>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
       
    </div>
</div>
<div class="section-space40">
        <!-- top location -->
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title mb60 text-center">
                        <h1>Featured Supplires</h1>
                        <p>thousand of product we are offering our best features products so you can get better way.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = CommonClass::FeqaturedSeller()->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <div class="real-wedding-block mb30">
                        <!-- real wedding block -->
                        <div class="real-wedding-img">
                            <a href="<?php echo e(url("supplier/$serow->company_slug/$serow->unique_code")); ?>"><img src="<?php echo e(asset($serow->logo)); ?>" alt="<?php echo e($serow->company_name); ?>" class="img-responsive custimg-seller"></a>
                        </div>
                        <div class="real-wedding-info well-box text-center">
                            <h2 class="real-wedding-title"><a href="<?php echo e(url("supplier/$serow->company_slug/$serow->unique_code")); ?>" class="title"><?php echo e($serow->company_name); ?></a></h2>
                            <p class="real-wed-meta"><span class="wed-day-meta"><i class="icon-wedding-day icon-size-18"></i> <?php echo e($serow->category_name); ?></span></p>
                        </div>
                    </div>
                    <!-- /.real wedding block -->
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div class="section-space40">
        <!-- top location -->
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title mb60 text-center">
                        <h1>Our Partner's</h1>
                        <p>thousand of product we are offering our best features products so you can get better way.</p>
                    </div>
                </div>
            </div>
            <div class="row ">
                <div class="col-md-12 tp-testimonial">
                    <div id="productcaro1" class="owl-carousel owl-theme clienttesto">
                        <div class="item testimonial-block">
                            <div class="couple-pic"><a href="#"><img src="<?php echo e(asset('webtheme/images/clients/1.png')); ?>" alt="" class="img-responsive" ></a></div>
                        </div>
                        <div class="item testimonial-block">
                            <div class="couple-pic"><a href="#"><img src="<?php echo e(asset('webtheme/images/clients/2.png')); ?>" alt="" class="img-responsive" ></a></div>
                        </div>
                        <div class="item testimonial-block">
                            <div class="couple-pic"><a href="#"><img src="<?php echo e(asset('webtheme/images/clients/3.png')); ?>" alt="" class="img-responsive" ></a></div>
                        </div>
                        <div class="item testimonial-block">
                            <div class="couple-pic"><a href="#"><img src="<?php echo e(asset('webtheme/images/clients/4.png')); ?>" alt="" class="img-responsive" ></a></div>
                        </div>
                        <div class="item testimonial-block">
                            <div class="couple-pic"><a href="#"><img src="<?php echo e(asset('webtheme/images/clients/6.png')); ?>" alt="" class="img-responsive" ></a></div>
                        </div>
                        <div class="item testimonial-block">
                            <div class="couple-pic"><a href="#"><img src="<?php echo e(asset('webtheme/images/clients/7.png')); ?>" alt="" class="img-responsive" ></a></div>
                        </div>
                        <div class="item testimonial-block">
                            <div class="couple-pic"><a href="#"><img src="<?php echo e(asset('webtheme/images/clients/8.png')); ?>" alt="" class="img-responsive" ></a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('footerscript'); ?>
<script>
    $("#productcaro1").owlCarousel({
  
      navigation : false, // Show next and prev buttons
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem:false,
      autoPlay: 5000,
      items : 5,
 
      // "singleItem:true" is a shortcut for:
      // items : 1, 
      // itemsDesktop : false,
      // itemsDesktopSmall : false,
      // itemsTablet: false,
      // itemsMobile : false
 
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>