<?php ($row=CommonClass::WebsiteProfile()); ?>
<div class="top-bar">
    <div class="container">
        <div class="row">
            <div class="col-md-6 top-message">
                <p>Call: <?php echo e($row->phone_no); ?></p>
            </div>
            <div class="col-md-6 top-links">
                <ul class="listnone">
                    <li><a href="<?php echo e(url('support')); ?>"> Support </a></li>
                    <?php if(auth()->guard()->guest()): ?>
                    <li><a href="#" data-toggle="modal" data-target="#exampleModal">Register</a></li>
                    <li><a href="<?php echo e(route('login')); ?>">Log in</a></li>
                    <?php else: ?>
                    <?php if(auth()->check() && auth()->user()->hasRole('seller')): ?>
                     <li><a href="<?php echo e(url('seller/home')); ?>">My Account</a></li>
                    <?php else: ?>
                    <li><a href="<?php echo e(url('buyer/home')); ?>">My Account</a></li>
                    <?php endif; ?>
                    <li><a href="#" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();"><i class="ti-power-off m-r-5"></i> Logout</a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>

                        </form></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
           
        </div>
    </div>
    <div class="header">
        <div class="container">
            
            <div class="row">
                <div class="col-md-3 col-sm-12 col-xs-3 logo">
                    <div class="navbar-brand">
                        <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset($row->logo)); ?>" alt="Wedding Vendors" class="img-responsive" style="height: 50px"></a>
                    </div>
                </div>
                <div class="col-md-9 col-sm-12 col-xs-9">
                    <div data-ride="carousel">
                    <!-- Wrapper for slides -->
                  </div>
                    <div >
                        <ul class="exo-menu">
                            <li class="active"><a href="<?php echo e(url('/')); ?>">Home</a>
                            </li>
                            <li class="mega-drop-down"><a href="#">Suppliers</a>
                                <div class="animated fadeIn mega-menu">
                                    <div class="mega-menu-wrap">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <h4 class="row mega-title">Browse Suppliers</h4>
                                            </div>
                                            <div class="col-md-12">
                                                <ul class="stander li25">
                                                    <?php $__currentLoopData = CommonClass::category(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catrow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><a href="<?php echo e(url("search?search=seller-in-africa&category=$catrow->category_slug")); ?>"><?php echo e($catrow->category_name); ?></a></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>  
                                </div>
                            </li>
                            <li class="mega-drop-down"><a href="#">Buyers</a>
                                <div class="animated fadeIn mega-menu">
                                    <div class="mega-menu-wrap">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <h4 class="row mega-title">Browse Buyers</h4>
                                            </div>
                                            <div class="col-md-12">
                                                <ul class="stander li25">
                                                    <?php $__currentLoopData = CommonClass::category(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catrow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><a href="<?php echo e(url("search?search=buyer-in-africa&category=$catrow->category_slug")); ?>"><?php echo e($catrow->category_name); ?></a></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>  
                                </div>
                            </li>
                            <li class="drop-down"><a href="#">Featured</a>
                                <!--Drop Down-->
                                <ul class="drop-down-ul animated fadeIn">
                                    <li><a href="<?php echo e(url("featured-products")); ?>">Feature Products</a></li>
                                    <li><a href="<?php echo e(url("featured-suppliers")); ?>">Feature Suppliers</a></li>
                                   
                                </li>
                            </ul>
                        </li>
                        <li ><a href="#" data-toggle="modal" data-target="#directoryModal">Download Directory</a>
                            <div class="animated fadeIn mega-menu">
                                <div class="mega-menu-wrap">
                                    <div class="row">
                                        <div class="col-sm-4">
                                           <h4 class="row mega-title">Sector Wise</h4>
                                           <ul class="stander">
                                                <?php $__currentLoopData = CommonClass::GetSector(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><a href="<?php echo e(url("sectors-directory/$crow->sector_slug")); ?>"><img src="<?php echo e(asset($crow->image)); ?>" width="20"> <?php echo e($crow->sector_name); ?></a></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                        <div class="col-md-8">
                                             <h4 class="row mega-title">Country Wise</h4>
                                            <ul class="stander li33">
                                                <?php $__currentLoopData = CommonClass::GetCountry(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><a href="<?php echo e(url("countries-directory/$crow->country_slug")); ?>"><img src="<?php echo e(asset($crow->country_flag)); ?>" width="20"> <?php echo e($crow->country_name); ?></a></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>  
                            </div>
                        </li>
                        <li class="drop-down"><a href="#">News</a>
                                <!--Drop Down-->
                                <ul class="drop-down-ul animated fadeIn">
                                    <li><a href="<?php echo e(url("business-news")); ?>">Business News</a></li>
                                    <li><a href="<?php echo e(url("blogs")); ?>">Blog</a></li>
                                </li>
                            </ul>
                        </li>
                        <a href="#" class="toggle-menu visible-xs-block">|||</a> 
                    </ul>
                </div>
                
                
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="directoryModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"> Download Directory</h4>
      </div>
      <div class="modal-body">
         <div class="row">
            <div class="col-md-6 center-block">
                <a href="#" class="btn btn-info btn-md center-block" data-toggle="modal" data-target="#sectorModal"><i class="fa fa-home fa-4x"></i><br>Sector Wise</a>
            </div>
            <div class="col-md-6 center-block">
                <a href="" class="btn btn-primary btn-md center-block" data-toggle="modal" data-target="#countryModal"><i class="fa fa-globe fa-4x"></i><br>Country Wise</a>
            </div>
        </div>
      </div>
    </div>

  </div>
</div>
<!-- Modal -->
<div id="sectorModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"> Download Industry wise directory</h4>
      </div>
      <div class="modal-body">
         <div class="row">
          <div class="col-sm-12">
             <ul class="dir-ul li32">
                <?php $__currentLoopData = CommonClass::GetSector(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(url("sectors-directory/$crow->sector_slug")); ?>"><img src="<?php echo e(asset($crow->image)); ?>" width="20"> <?php echo e($crow->sector_name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        </div>
      </div>
    </div>

  </div>
</div>
<!-- Modal -->
<div id="countryModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"> Download Country wise directory</h4>
      </div>
      <div class="modal-body">
         <div class="row">
          <div class="col-sm-12">
             <ul class="dir-ul li32">
                <?php $__currentLoopData = CommonClass::GetCountry(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(url("countries-directory/$crow->country_slug")); ?>"><img src="<?php echo e(asset($crow->country_flag)); ?>" width="20"> <?php echo e($crow->country_name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        </div>
      </div>
    </div>

  </div>
</div>