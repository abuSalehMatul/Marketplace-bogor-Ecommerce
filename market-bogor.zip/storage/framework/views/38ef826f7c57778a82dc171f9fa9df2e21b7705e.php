
<?php $__env->startPush('headerscript'); ?>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('custom/style.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="tp-page-head">
  <!-- page header -->
  <div class="container">
    <div class="row">
      <div class="col-md-offset-2 col-md-8">
        <div class="page-header text-center">
          <h1>Register as a Buyer</h1>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="section-space80">
  <!-- Feature Blog Start -->
  <div class="container ">
    <div class="row">
      <div class="col-md-6 col-md-offset-3">
       <section class="form-box">

        <div class="row">
          <div class="col-md-12">

            <!-- Form Wizard -->
            <div class="form-wizard form-header-classic form-body-classic">
              <h3><i class="fa fa-user"></i> Join <b>Free</b> As Buyer</h3>
              <form role="form" class="section-space40" action="<?php echo e(url('buyer-store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <input type="text" name="first_name" value="<?php echo e(old('first_name')); ?>" class="form-control" placeholder="First Name*" required="">
                      <span class="text-danger"><?php echo e($errors->first('first_name')); ?></span>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <input type="text" name="last_name" value="<?php echo e(old('last_name')); ?>" class="form-control" placeholder="Last Name*" required="">
                      <span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <?php echo Form::select('instant_type',[''=>'-Select Your Instant Type-','1'=>'WhatsApp','2'=>'Skype','3'=>'WeChat'], old('instant_type'),  ['class'=>'form-control ', 'required'=>'']); ?>

                      <span class="text-danger"><?php echo e($errors->first('instant_type')); ?></span>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <input type="text" name="instant_id" value="<?php echo e(old('instant_id')); ?>" class="form-control" placeholder="Enter Instant ID*" required="">
                      <span class="text-danger"><?php echo e($errors->first('instant_id')); ?></span>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <input type="text" name="username" value="<?php echo e(old('first_name')); ?>" class="form-control" placeholder="E-mail*" required="">
                      <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <input type="password" name="password" id="new_password" value="<?php echo e(old('password')); ?>" class="form-control" placeholder="Password*" required="">
                      <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <input type="password" name="password_confirmation" id="confirm_password" value="<?php echo e(old('password_confirmation')); ?>" placeholder="Confirm Password*" class="form-control" required="">
                      <span class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></span>
                    </div>
                  </div>
                  <span id="password_error"></span>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <input type="checkbox" id="confirm" name="confirm" required="" > <label for="confirm">“I agree to the <a target="_blank" href="<?php echo e(url('privacy-policy')); ?>">Terms and Conditions</a>” or “I agree to the <a target="_blank" href="<?php echo e(url('terms-conditions')); ?>">Privacy Policy</a>” of Business Directory.</label>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <button name="submit" class="pull-right btn btn-primary btn-sm">Save</button>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-12">
                    <a href="<?php echo e(url('buyer-register')); ?>">Join as Seller</a>
                  </div>
                </div>

              </form>

            </div>
            <!-- Form Wizard -->
          </div>
        </div>

      </section>

    </div>
  </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('footerscript'); ?>
<script>
  $(document).ready(function(){
    $("#new_password, #confirm_password").keyup(checkpassword);

  });

  function checkpassword(){
    var password=$("#new_password").val();
    var confirmpassword=$("#confirm_password").val();
    if(confirmpassword.length>0){
      if(password!=confirmpassword){
        $("#password_error").html("Password did not matched");
      }
      else{
        $("#password_error").html("Password matched");
      }
    }
  }
</script>
<script>
  function validateForm(){
    var password=document.getElementById("new_password").value;
    var confirmpassword=document.getElementById("confirm_password").value;
    if(password!=confirmpassword){
      $("#password_error").html("Password did not matched");
      return false;
    }
    else{
      return true;
    }
  }
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>