<?php $__env->startSection('title','Fronted_Control'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-page">
  <div class="content">
    <div class="container">
        <?php
            $all_plan=DB::table('seller_plans')->get();
           // print_r($all_plan);
           $message=Session::get('message');
        ?>
        <h4 class="text-center text-danger"><?php echo e($message); ?></h4>
        <?php $__currentLoopData = $all_plan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <?php
          $plan_priority=DB::table('seller_plan_priorities')->where('seller_plan_id',$plan->id)->first(); 
           Session::forget('message');
        ?>
        <form action="<?php echo e(url('admin/priority_save_to_db/'.$plan->id)); ?>" method="post"> 
            <?php echo csrf_field(); ?>   
            <div class="card">
                <div class="card-header">
                    <h2><?php echo e($plan->plan_name); ?></h2>
                </div>
                <div class="card-body">
                    <div>
                        <label>Priority</label>
                        <input type="number" name="priority" placeholder="Priority" class="" style="display:inline" required>
                        <?php if($plan_priority): ?>
                        <h6 style="display:inline"><?php echo e($plan_priority->priority); ?></h6>
                        <?php endif; ?>
                    </div>
                    <div>
                        <label>Size</label>
                        <input type="number" name="array_size" placeholder="ex:4" class="" style="display:inline" required>
                        <?php if($plan_priority): ?>
                        <h6 style="display:inline"><?php echo e($plan_priority->array_size); ?></h6>
                        <?php endif; ?>
                    </div>
                    
                
                
                </div>
                
                 <input type="submit" class="btn btn-success float-right" style=""  >
            </div>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
       
    </div>
  </div>
  <script>
  function save_to_db(id){
      console.log(id);
      $.ajax({
              type:'get',
              url:'<?php echo e(URL::to('admin/priority_save_to_db')); ?>',
              data:{'id':id},
              success:function(data){
                 console.log('success');
                // console.log(data);
                 location.reload();
                
                
              }
          })
  }
  </script>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>