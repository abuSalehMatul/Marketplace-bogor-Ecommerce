<?php $__env->startPush('headerscript'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('webtheme/css/sidebar.css')); ?>">
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
<?php 
$user=Auth::user();
$seller=$user->seller;
?>
<div class="tp-dashboard-head">
  <!-- page header -->
  <div class="container">
    <div class="row">
      <div class="col-md-12 profile-header">
        <div class="profile-pic col-md-2"><img src="images/profile-dashbaord.png" alt=""></div>
        <div class="profile-info col-md-9">
          <h1 class="profile-title"><?php echo e($seller->first_name); ?><small>Welcome Back memeber</small></h1>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- /.page header -->

<div class="main-container">
  <div class="container">
    <div class="row">
      <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="col-md-9">
        <div class="row well-box">
          <div class="col-xs-12 ">
            <div class="page-title-box">
              <h4 class="page-title pull-left">Products</h4>
              <div class="clearfix"><a href="<?php echo e(route('sell.index')); ?>" class="pull-right btn btn-info btn-sm"><i class="fa fa-backward"></i> Back</a></div>
            </div>
          </div>
          <div class="col-xs-12 section-space20">
            <form action="<?php echo e(route('sell.store')); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <div class="row">
               <div class="form-group">
                 <div class="col-sm-8">
                   <label for="">Product Name</label>
                   <input type="text" name="product_name" class="form-control" required="" value="<?php echo e(old('product_name')); ?>">
                   <div class="text-danger"><?php echo e($errors->first('product_name')); ?></div>
                 </div>
                 <div class="col-sm-4">
                   <label for="">Price</label>
                   <input type="text" name="product_price" class="form-control" value="<?php echo e(old('product_name')); ?>">
                   <div class="text-danger"><?php echo e($errors->first('product_name')); ?></div>
                 </div>
               </div>
             </div>
             <div class="row">
              <div class="form-group">
                <div class="col-sm-12">
                  <label for="">Short Description</label>
                  <textarea name="short_description" maxlength="200" class="form-control"><?php echo e(old('short_description')); ?></textarea>
                  <div class="text-danger"><?php echo e($errors->first('short_description')); ?></div>
                </div>
              </div>
            </div>
            <div class="row">
             <div class="form-group">
               <div class="col-sm-12">
                 <label for="">Full Description</label>
                 <textarea name="full_description" maxlength="2000" class="form-control"><?php echo e(old('full_description')); ?></textarea>
                 <div class="text-danger"><?php echo e($errors->first('full_description')); ?></div>
               </div>
             </div>
           </div>

           <div class="row">
             <div class="form-group">
               <div class="col-sm-12">
                 <label for="">Featured Image</label>
                 <input type="file" name="featured_image" class="form-control" required="" accept="image/*" required="">
                 <div class="text-danger"><?php echo e($errors->first('featured_image')); ?></div>
               </div>
             </div>
           </div>
           <div class="row">
             <table class="table table-hover mul">
              <thead>
                <tr>
                  <th>Product Images</th>
                  <th><button type="button" class="btn btn-success btn-sm" id="add_row"><i class="fa fa-plus"></i> Add More</button></th>
                </tr>
              </thead>
              <tbody >
                <tr>
                  <td>
                    <input type="file" name="product_image[]" class="form-control" required="" accept="image/*" required="">
                    <div class="text-danger"><?php echo e($errors->first('product_image')); ?></div>
                  </td>
                  <td>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="row">
            <div class="form-group">
              <div class="col-md-12">
                <button class="btn btn-primary btn-sm pull-right" type="submit">Save</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('footerscript'); ?>
<script>
  
  $(document).ready(function(){
    var i = 1;
    $('#add_row').on('click',function(){
      var newrow=$("<tr>");
      var col="";
      col += '<td><input type="file" name="product_image[]" class="form-control" required="" accept="image/*" required=""></td>';
      col += '<td><button class="btn btn-danger" id="deletebutton"><i class="fa fa-times"></i></button></td>';
      newrow.append(col); i++;
      $("table.mul").append(newrow);
    });

    $("table.mul").on("click", "#deletebutton", function(event){
      $(this).closest("tr").remove();
    });

  });

</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>