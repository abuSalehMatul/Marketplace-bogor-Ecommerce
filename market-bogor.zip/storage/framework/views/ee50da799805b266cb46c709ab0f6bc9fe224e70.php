<?php $__env->startSection('title','Buyer Safety'); ?>
<?php $__env->startPush('headerscript'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('webtheme/css/fontello.css')); ?>">
<style>
.nav-tabs a{
    color#000 !important;
}
.tp-page-head{
    background: linear-gradient(rgba(6, 63, 63, 0.8), rgba(6, 63, 63, 0.8)), rgba(6, 63, 63, 0.8) url(webtheme/images/page-header-img.jpg) no-repeat center;
    background-size: cover;
    color: #fff;
    height: 150px;
    margin-top: -40px;

}


</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="main-container">
    <div class="contaier">
        <div class="row">
            

                <div class="tp-page-head">
                    <!-- page header -->
                    <div class="container">
                        <div class="row">
                            <div class="col-md-offset-2 col-md-8">
                                <div class="page-header">
                                    
                                    <h1>Safety For Buyer</h1>
                                    <p></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.page header -->
                <div class="tp-breadcrumb">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-8">
                                <ol class="breadcrumb">
                                    <li><a href="#">Home</a></li>
                                    <li class="active">Buyer Buyer</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="main-container">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-3 side-nav" id="leftCol">
                                <div class="hide-side">
                                    <ul class="listnone nav" id="sidebar">
                                        <li class="active"><a href="<?php echo e(url('buyersafety')); ?>">Safety</a></li>
                                        <li><a href="<?php echo e(url('faq-for-buyer')); ?>">FAQ</a></li>
                                        <li><a href="<?php echo e(url('help-for-buyer')); ?>">help</a>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-md-9 content-right">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="aboutus" id="aboutus">
                                                <h1>Buyer Safety</h1>
                                                <p class="lead"><?php echo e($r->full_description); ?></p>

                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>


                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="container">
                     <?php ($row=CommonClass::WebsiteProfile()); ?>
                     <div class="col-sm-12 ">
                        <h3>Other ways to contact us</h3>
                        <div class="col-sm-3">
                            <h4><i class="icon-phone-call icon-size-60 icon-light"></i></h4>
                            <h4><a href="tel:<?php echo e($row->phone_no); ?>">Call Us</a></h4>
                            <p>We're here to help.</p>
                        </div>
                        <div class="col-sm-3">
                            <h4><i class="icon-email-1 icon-size-60 icon-light"></i></h4>
                            <h4><a href="mailto:<?php echo e($row->email_id); ?>">Email</a></h4>
                            <p>Respond within 24 hours</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>