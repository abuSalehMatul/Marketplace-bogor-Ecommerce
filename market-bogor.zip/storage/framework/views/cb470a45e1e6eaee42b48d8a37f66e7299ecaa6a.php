<?php $__env->startSection('title','Seller List'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-page">
  <!-- Start content -->
  <div class="content">
    <div class="container">
        <?php
            $subscriber=App\Models\Subscriber::all();
        ?>
        <table class="table table-striped">
            <thead>
                <tr>
                <th scope="col">Email</th>
                <th scope="col">Website User</th>
                <th scope="col">Email verified</th>
                <th scope="col">Date/Time of Subscription</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $subscriber; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <th scope="row"><?php echo e($subscriber->email); ?></th>

                <?php
                    $website_user=App\User::where('email',$subscriber->email)->count();
                ?>
               
                     <?php if($website_user > 0): ?>
                       <td><i class="fas fa-check-circle"></i></td>
                     <?php else: ?> 
                     <td> <i class="fas fa-times"></i></td>
                     <?php endif; ?>
                 
                <?php
                   $str= $subscriber->verified_at;
                   if(strlen($str)>30){
                       $a=0;
                   }else{
                       $a=1;
                   }
                ?>
               
                    <?php if($a==0): ?>
                       <td> <i class="fas fa-times"></i></td>
                    <?php else: ?> 
                       <td> <i class="fas fa-check-circle"></i></td>
                    <?php endif; ?>
                 
                
                <td><?php echo e($subscriber->created_at); ?></td>
                </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>