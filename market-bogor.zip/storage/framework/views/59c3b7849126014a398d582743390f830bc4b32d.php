<?php $__env->startSection('title',"$row->title - Business News"); ?>
<?php $__env->startPush('headerscript'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="wide-post-image"> <img src="<?php echo e(asset($row->featured_image)); ?>" alt="" class="img-responsive" style="width: 100%;height: 400px"> </div>
    <div class="container blog-header">
        <div class="row blog-head">
            <div class="col-md-12 title">
                <h1><?php echo e($row->title); ?></h1>
                <div class="post-meta"> <span class="date-meta">ON <a href="#"><?php echo e(date('d F, Y',strtotime($row->created_at))); ?></a> /</span> <span class="admin-meta">BY <a href="#">Admin</a> </span> </div>
            </div>
        </div>
    </div>

<div class="section-space80">
    <!-- Feature Blog Start -->
    <div class="container ">
        <div class="row">
            <div class="col-sm-9 content-left">
                <div class="row">
                    <?php echo $row->full_description; ?>   
                </div>
            </div>
            <div class="col-md-3">
                <div class="filter-sidebar">
                    <?php echo $__env->make('layout.sidebanner', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
        <?php echo $__env->make('layout.bottomad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>
<!-- Go to www.addthis.com/dashboard to customize your tools --> <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5c3ca221186af4ba"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('footerscript'); ?>
<script src="<?php echo e(asset('custom/wizard.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>