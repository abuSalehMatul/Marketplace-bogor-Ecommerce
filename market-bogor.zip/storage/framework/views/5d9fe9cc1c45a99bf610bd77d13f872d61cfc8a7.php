
<?php $__env->startSection('title','Website Profile'); ?>
<?php $__env->startSection('content'); ?>

<div class="content-page">
  <!-- Start content -->
  <div class="content">
    <div class="container">
      <div class="row">
        <div class="col-xs-12">
          <div class="page-title-box">
            <h4 class="page-title">Website Profile</h4>
            <div class="clearfix"></div>
          </div>
        </div>
      </div>
      <!-- end row -->
      <div class="row">
        <div class="col-sm-12">
          <div class="card-box">
            <?php echo e(Form::open(array('route' => array('website-profile.update', $row->id),'class' =>'form-horizontal','method' =>'PATCH','files'=>true))); ?>

            <div class="row">
              <div class="form-group">
                <div class="col-sm-6">
                  <label for="">Logo</label>
                  <input type="file" onchange="loadFile(event, 'logo')" class="form-control" name="logo" value="" placeholder="">
                  <div class="text-danger"><?php echo e($errors->first('logo')); ?></div>
                </div>
                <div class="col-md-6">
                  <img src="<?php echo e(asset($row->logo)); ?>" class="img-thumbanil img-responsive" id="logo" alt="">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="form-group">
                <div class="col-sm-6">
                  <label>Website Name: <span>*</span></label>
                  <input type="text" name="website_name" value="<?php echo e(old('website_name',$row->website_name)); ?>" class="form-control" required>
                  <span class="text-danger"><?php echo e($errors->first('website_name')); ?></span>
                </div>
                <div class="col-sm-6">
                  <label>Phone No: <span>*</span></label>
                  <input type="tel" name="phone_no" value="<?php echo e(old('phone_no',$row->phone_no)); ?>" class="form-control" required>
                  <span class="text-danger"><?php echo e($errors->first('phone_no')); ?></span>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="form-group">
                <div class="col-sm-6">
                  <label>E-mail ID: <span>*</span></label>
                  <input type="text" name="email_id" value="<?php echo e(old('email_id',$row->email_id)); ?>" class="form-control" required="">
                  <span class="text-danger"><?php echo e($errors->first('email_id')); ?></span>
                </div>
                <div class="col-sm-6">
                  <label>Support E-mail ID: <span>*</span></label>
                  <input type="text" name="support_email_id" value="<?php echo e(old('support_email_id',$row->support_email_id)); ?>" class="form-control" required="">
                  <span class="text-danger"><?php echo e($errors->first('support_email_id')); ?></span>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="form-group">
                <div class="col-sm-12">
                  <label>Facebook Url: <span>*</span></label>
                  <input type="text" name="fb_url" value="<?php echo e(old('fb_url',$row->fb_url)); ?>" class="form-control" required="">
                  <span class="text-danger"><?php echo e($errors->first('fb_url')); ?></span>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="form-group">
                <div class="col-sm-12">
                  <label>Youtube Url: <span>*</span></label>
                  <input type="text" name="youtube_url" value="<?php echo e(old('youtube_url',$row->youtube_url)); ?>" class="form-control" required="">
                  <span class="text-danger"><?php echo e($errors->first('youtube_url')); ?></span>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="form-group">
                <div class="col-sm-12">
                  <label>Twitter Url: <span>*</span></label>
                  <input type="text" name="twitter_url" value="<?php echo e(old('twitter_url',$row->twitter_url)); ?>" class="form-control" required="">
                  <span class="text-danger"><?php echo e($errors->first('twitter_url')); ?></span>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="form-group">
                <div class="col-sm-12">
                  <label>Instgram Url: <span>*</span></label>
                  <input type="text" name="inst_url" value="<?php echo e(old('inst_url',$row->inst_url)); ?>" class="form-control" required="">
                  <span class="text-danger"><?php echo e($errors->first('inst_url')); ?></span>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="form-group">
                <div class="col-sm-12">
                  <label>Google+ Url: <span>*</span></label>
                  <input type="text" name="gplus_url" value="<?php echo e(old('gplus_url',$row->gplus_url)); ?>" class="form-control" required="">
                  <span class="text-danger"><?php echo e($errors->first('gplus_url')); ?></span>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="form-group">
                <div class="col-sm-12">
                  <label>Business Address: <span>*</span></label>
                  <textarea name="business_address" class="form-control"><?php echo e(old('business_address',$row->business_address)); ?></textarea>
                  <span class="text-danger"><?php echo e($errors->first('business_address')); ?></span>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="form-group">
                <div class="col-md-12">
                  <button class="pull-right btn btn-primary btn-sm" type="submit">Save</button>
                </div>
              </div>
            </div>
            <?php echo Form::close(); ?>

          </div>

        </div>
      </div>
    </div>
  </div> <!-- container -->
</div> <!-- content -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('footerscript'); ?>
<script>
  var loadFile = function (event, imgid) {
    var output = document.getElementById(imgid);
    output.src = URL.createObjectURL(event.target.files[0]);
  };
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>