<?php $__env->startSection('title','Blogs'); ?>
<?php $__env->startPush('headerscript'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="tp-page-head">
    <!-- page header -->
    <div class="container">
        <div class="row">
            <div class="col-md-offset-2 col-md-8">
                <div class="page-header text-center">
                    <h1>Blogs</h1>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="section-space80">
    <!-- Feature Blog Start -->
    <div class="container ">
        <div class="row">
            <div class="col-sm-9 content-left">
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                        <div class="col-md-12 post-holder">
                            <div class="well-box">
                                <div class="sticky-sign"><i class="fa fa-bookmark"></i></div>
                                <!-- blog holder -->
                                <div class="post-image">
                                    <a href="<?php echo e(asset("blog-detail/$row->slug/$row->unique_code")); ?>"><img src="<?php echo e(asset($row->featured_image)); ?>" class="img-responsive" alt=""></a>
                                </div>
                                <h1 class="post-title"><a href="<?php echo e(asset("blog-detail/$row->slug/$row->unique_code")); ?>"><?php echo e($row->title); ?></a></h1>
                                <div class="post-meta"> <span class="date-meta">ON <a href="#"><?php echo e(date('d F, Y',strtotime($row->created_at))); ?></a> /</span> <span class="admin-meta">BY Admin </span></div>
                                <p><?php echo e($row->short_description); ?></p>
                                <a href="<?php echo e(asset("blog-detail/$row->slug/$row->unique_code")); ?>" class="btn btn-default">Read More</a> </div>
                        </div>
                        <!-- /.blog holder -->
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-md-3">
                <div class="filter-sidebar">
                    <?php echo $__env->make('layout.sidebanner', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
         <?php echo $__env->make('layout.bottomad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('footerscript'); ?>
<script src="<?php echo e(asset('custom/wizard.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>