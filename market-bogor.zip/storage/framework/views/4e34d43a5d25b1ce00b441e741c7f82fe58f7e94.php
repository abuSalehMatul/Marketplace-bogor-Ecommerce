
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="www">
    <meta name="keywords" content="www">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Bootstrap -->
    <!--custom -->
     <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
    
    

    <link href="<?php echo e(asset ('webtheme/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- Template style.css -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset ('webtheme/css/style.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset ('webtheme/css/owl.carousel.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset ('webtheme/css/owl.theme.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset ('webtheme/css/owl.transitions.css')); ?>">
     <link rel="stylesheet" type="text/css" href="<?php echo e(asset ('webtheme/css/style.css')); ?>">
    
    <!-- Font used in template -->
    <link href='https://fonts.googleapis.com/css?family=Montserrat:400,700|Roboto:400,400italic,500,500italic,700,700italic,300italic,300' rel='stylesheet' type='text/css'>
    <!--font awesome icon -->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- favicon icon -->
   
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('webtheme/css/custom.css')); ?>">
    <script src="<?php echo e(asset('webtheme/js/jquery.min.js')); ?>"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js') }}"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js') }}"></script>
  <![endif]-->
  <?php echo $__env->yieldPushContent('headerscript'); ?>
</head>

<body>
    
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php $__env->startSection('content'); ?>
    <?php echo $__env->yieldSection(); ?>
    
    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldPushContent('footerscript'); ?>
    <?php echo $__env->make('admin.layout.notificaton', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
</body>


</html>
