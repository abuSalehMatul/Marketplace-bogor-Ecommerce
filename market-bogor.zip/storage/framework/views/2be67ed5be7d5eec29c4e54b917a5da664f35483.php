<?php $__env->startSection('content'); ?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">


            <div class="row">
                <div class="col-xs-12">
                    <div class="page-title-box">
                        <h4 class="page-title">Edit Category</h4>
                        <div class="clearfix"><a href="<?php echo e(route('category.create')); ?>" class="pull-right btn btn-info btn-sm"><i class="fa fa-plus"></i> Add New</a></div>
                    </div>
                </div>
            </div>
            <!-- end row -->
            <div class="row">
                <div class="col-xs-12">
                    <div class="card-box">
                        <?php echo e(Form::open(array('route' => array('category.update', $row->id),'class' =>'form-horizontal','method' =>'PATCH'))); ?>

                        <div class="row">
                            <div class="form-group">
                                <div class="col-md-2 col-md-offset-1">
                                    <label>Category Name</label>
                                </div>
                                <div class="col-md-6">
                                    
                                    <input type="text" name="category_name" value="<?php echo e($row->product_category); ?>" class="form-control">
                                </div>
                                <div class="col-md-2 text-center">
                                    <button class=" btn btn-primary" type="submit">Save</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>


    </div> <!-- container -->

</div> <!-- content -->

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>