<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('theme/default/plugins/bootstrap-sweetalert/sweet-alert.css')); ?>" rel="stylesheet" type="text/css">
<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">


            <div class="row">
                <div class="col-xs-12">
                    <div class="page-title-box">
                        <h4 class="page-title">Edit Community</h4>
                        <div class="clearfix"><a href="<?php echo e(route('community.index')); ?>" class="pull-right btn btn-info btn-sm"><i class="fa fa-backward"></i> Back</a></div>
                    </div>
                </div>
            </div>
            <!-- end row -->
            <div class="row">
                <div class="col-xs-12">
                    <div class="card-box">
                        <?php echo e(Form::open(array('route' => array('community.update', $row->id),'class' =>'form-horizontal','method' =>'PATCH'))); ?>

                        <div class="row">
                            <div class="form-group">
                                <div class="col-md-12">
                                    <label>Facebook</label>
                                    <input type="text" name="fb" value="<?php echo e(old('fb',$row->fb)); ?>" placeholder="Enter here..." class="form-control">
                                    <div class="text-danger"><?php echo e($errors->first('fb')); ?></div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group">
                                <div class="col-md-12">
                                    <label>Twitter</label>
                                    <input type="text" name="twitter" value="<?php echo e(old('twitter',$row->twitter)); ?>" placeholder="Enter here..." class="form-control">
                                    <div class="text-danger"><?php echo e($errors->first('twitter')); ?></div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group">
                                <div class="col-md-12">
                                    <label>WhatApp</label>
                                    <input type="text" name="whatsapp" value="<?php echo e(old('whatsapp',$row->whatsapp)); ?>" placeholder="Enter here..." class="form-control">
                                    <div class="text-danger"><?php echo e($errors->first('whatsapp')); ?></div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group">
                                <div class="col-md-12">
                                    <label>Google+</label>
                                    <input type="text" name="gplus" value="<?php echo e(old('gplus',$row->gplus)); ?>" placeholder="Enter here..." class="form-control">
                                    <div class="text-danger"><?php echo e($errors->first('gplus')); ?></div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group">
                                <div class="col-md-12">
                                    <label>Instagram</label>
                                    <input type="text" name="instagram" value="<?php echo e(old('instagram',$row->instagram)); ?>" placeholder="Enter here..." class="form-control">
                                    <div class="text-danger"><?php echo e($errors->first('instagram')); ?></div>
                                </div>
                            </div>
                        </div>
                            <div class="row">
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <button class="btn btn-primary" type="submit">Save</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>


    </div> <!-- container -->

</div> <!-- content -->

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>