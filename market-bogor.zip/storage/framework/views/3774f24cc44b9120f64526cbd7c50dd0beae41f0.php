<html>
<head></head>
<body style="background: black; color: #ccc">
	<p><b>Hello</b> <?php echo e("$first_name $last_name"); ?></p>
	<p>Thank you for regsitered with us as a <?php echo e($type); ?></p>
	<p>Please verify your account</p>
	<a href="<?php echo e(url('verify-account/'.encrypt($user_id))); ?>" target="_blank">Click for verify</a>
</body>
</html>
