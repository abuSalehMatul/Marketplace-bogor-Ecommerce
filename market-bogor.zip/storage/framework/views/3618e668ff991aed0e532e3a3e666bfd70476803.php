
<?php $__env->startSection('title','Country'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">


            <div class="row">
                <div class="col-xs-12">
                    <div class="page-title-box">
                        <h4 class="page-title">Edit Country</h4>
                        <div class="clearfix"><a href="<?php echo e(route('country.create')); ?>" class="pull-right btn btn-info btn-sm"><i class="fa fa-plus"></i>&nbsp;&nbsp;Add New</a></div>
                    </div>
                </div>
            </div>
            <!-- end row -->
            <div class="row">
                <div class="col-xs-12">
                    <div class="card-box">
                        <?php echo e(Form::open(array('route' => array('country.update', $row->id),'class' =>'form-horizontal','method' =>'PATCH','files'=>true))); ?>

                            <div class="row">
                               <div class="form-group">
                                   <div class="col-sm-6">
                                       <label for="">Country Name</label>
                                       <input type="text" name="country_name" class="form-control" required="" value="<?php echo e(old('country_name',$row->country_name)); ?>">
                                       <div class="text-danger"><?php echo e($errors->first('country_name')); ?></div>
                                   </div>
                               </div>
                           </div>
                           <div class="row">
                               <div class="form-group">
                                   <div class="col-sm-6">
                                       <label for="">Country Flag Icon</label>
                                       <input type="file" name="country_flag" class="form-control" onchange="loadFile(event, 'logos')" accept="image/*">
                                       <div class="text-danger"><?php echo e($errors->first('country_flag')); ?></div>
                                   </div>
                                   <div class="col-sm-6">
                                    <img src="<?php echo e(asset($row->country_flag)); ?>" alt="" id="logos" >
                                   </div>
                               </div>
                           </div>
                        <div class="row">
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <button class="btn btn-primary btn-sm" type="submit">Save</button>
                                    </div>
                                </div>
                            </div>
                    </form>
                </div>
            </div>
        </div>


    </div> <!-- container -->

</div> <!-- content -->

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>