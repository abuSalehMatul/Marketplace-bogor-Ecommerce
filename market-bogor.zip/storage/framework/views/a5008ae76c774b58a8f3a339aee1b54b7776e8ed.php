<?php $__env->startPush('headerscript'); ?>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('custom/style.css')); ?>">
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

<div class="section-space80">
    <!-- Feature Blog Start -->
    <div class="container ">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <h2 class="text-center">Login Now</h2>
               <form action="<?php echo e(route('login')); ?>" method="post" >
                <?php echo csrf_field(); ?>
                    <div class="col-md-12">
                        <div class="form-group">
                            <input type="text" name="email" value="" placeholder="Email Id" class="form-control"> 
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <input type="password" name="password" value="" placeholder="Password" class="form-control"> 
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </form> 
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('footerscript'); ?>
<script src="<?php echo e(asset('custom/wizard.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>