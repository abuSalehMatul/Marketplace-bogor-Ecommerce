<?php 
$sellin=($sell_in==1)?'Africa':'Global';
?>
<?php $__env->startSection('title',"Buyer's in $sellin"); ?>
<?php $__env->startPush('headerscript'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="tp-page-head">
    <!-- page header -->
    <div class="container">
        <div class="row">
            <div class="col-md-offset-2 col-md-8">
                <div class="page-header text-center">
                    <h1>Buyer's in <?php echo e($sellin); ?></h1>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="filter-box">
    <div class="container">
        <div class="row filter-form">
            <form action="<?php echo e(url('search')); ?>" method="get">
                 <div class="col-md-3">
                    <?php echo Form::select('for',['companies'=>'Companies','products'=>'Products'], old('for'),  ['class'=>'form-control ', 'required'=>'']); ?>

                </div>
                <div class="col-md-3">
                    <?php echo Form::select('search',['buyer-in-africa'=>'Buyer In Africa','buyer-in-global'=>'Buyer In Globel','3'=>'All'], old('search',$type),  ['class'=>'form-control ', 'required'=>'']); ?>

                </div>
                <div class="col-md-3">
                    <?php echo Form::select('category',[''=>'--Select Category--']+CommonClass::CategoryList1(), old('product'),  ['class'=>'form-control ', 'required'=>'']); ?>

                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary btn-block">Search</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="section-space80">
    <!-- Feature Blog Start -->
    <div class="container ">
        <div class="row">
            <div class="col-md-3 left-sidebar">
                <div class="col-md-12 widget widget-category">
                    <!-- widget -->
                    <div class="well-box">
                        <h2 class="widget-title">Categories</h2>
                        <ul class="listnone angle-double-right sidebarlist">
                            <?php $__currentLoopData = CommonClass::category(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catrow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(url("search?search=$type&category=$catrow->category_slug")); ?>"><?php echo e($catrow->category_name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <img src="<?php echo e(asset('webtheme/images/banner/2.jpg')); ?>" class="img-thumbnail" alt="">
                </div>
            </div>
            <div class="col-sm-6">
                <h2 class="widget-title">Featured Listing</h2>
                <?php $__currentLoopData = $buyer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="vendor-box-list">
                    <!-- vendor list -->
                    <div class="row">
                        <!-- /.venue pic -->
                        <div class="col-md-12">
                            <!-- venue details -->
                            <div class="vendor-list-details">
                                <div class="caption">
                                    <!-- caption -->
                                    <h2><a href="#" class="title"><?php echo e($row->first_name); ?></a></h2>
                                    <p class="location"><i class="fa fa-map-marker"></i> <?php echo e("$row->state, "); ?> <?php echo e(CommonClass::GetCountryName($row->country)); ?></p>
                                </div>
                                <!-- /.caption -->

                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="vendor-price">
                                <a href="#" class="btn btn-info btn-sm">Read More</a>&nbsp;&nbsp;
                                <a href="#" class="btn btn-info btn-sm">Send Mail</a>
                            </div>
                        </div>

                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-md-3">
                <div class="filter-sidebar">
                    <div class="col-md-12 form-group">
                        <img src="<?php echo e(asset('webtheme/images/banner/1.jpg')); ?>" class="img-thumbnail" alt="">
                        <img src="https://i1.wp.com/www.ngodoctor.com/wp-content/uploads/2017/07/5063925-hd-business-wallpaper.jpg?fit=1200%2C600" class="img-thumbnail" alt="">
                        <img src="<?php echo e(asset('webtheme/images/vendor-1.jpg')); ?>" class="img-thumbnail" alt="">
                        <img src="http://images6.fanpop.com/image/photos/40000000/apps-for-business-eraashu001-40063496-1920-650.jpg" class="img-thumbnail" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('footerscript'); ?>
<script src="<?php echo e(asset('custom/wizard.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>