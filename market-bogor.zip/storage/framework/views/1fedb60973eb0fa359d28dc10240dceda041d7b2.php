<?php $__env->startSection('title','Login'); ?>
<?php $__env->startSection('content'); ?>

<div class="section-space80">
  <!-- Feature Blog Start -->
  <div class="container ">

    <div class="row">
      <div class="col-md-10 col-md-offset-1">

        <div class="col-md-8 border border-right st-tabs">
          <!-- Nav tabs -->
          <div class="well-box">
            <div class="row">
              <div class="col-md-12">
                <?php if(Session::has('success_msg')): ?>
                <p class="alert alert-info"><?php echo e(Session::get('success_msg')); ?></p>
                <?php endif; ?>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <h3>Login Now</h3>
              </div>
            </div>
            <form action="<?php echo e(route('login')); ?>" method="post" >
              <?php echo csrf_field(); ?>
              <!-- Text input-->
              <div class="form-group">
                <input type="text" name="email" value="" placeholder="Email Id" class="form-control"> 
                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
              </div>
              <!-- Text input-->
              <div class="form-group">
                <input type="password" name="password" value="" placeholder="Password" class="form-control"> 
                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
              </div>
              <!-- Button -->
              <div class="form-group">
                <button id="submit" name="submit" class="btn btn-primary btn-lg">Login</button>
                <a href="<?php echo e(route('password.request')); ?>" class="pull-right"> <small>Forgot Password ?</small></a>
              </div>
            </form>
          </div>

        </div>

        <div class="col-md-4 border border-right st-tabs">
          <!-- Nav tabs -->
          <div class="well-box">
            <h2>Why Register?</h2>
            <hr>
            <ul class="list-group">
              <li class="list-group">Post Buy/Sell leads</li>
              <li class="list-group">List Your Business</li>
              <li class="list-group">Message contacts</li>
              <li class="list-group">Access Premium Content</li>
              <li class="list-group">Industry Newsletters</li>
            </ul>
          </div>

        </div>

      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>