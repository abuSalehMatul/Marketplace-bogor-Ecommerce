<?php $__env->startSection('title','Partner_list'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-page">
  <!-- Start content -->
  <div class="content">
    <div class="container">
      <?php
          $message=Session::get('message');
      ?>
      <?php if($message): ?>
      <h5 class="text-center text-success"><?php echo e($message); ?></h5>
      <?php endif; ?>
        <table class="table">
          <tr>
            <td>Image</td>
            <td>Name</td>
            <td>URL</td>
            <td colspan="2">Description</td>
            <td></td>
            <td></td>
          </tr>
            <?php
                $partner=App\Models\Partner::all();
            ?>
           
            <?php $__currentLoopData = $partner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><img src="<?php echo e(asset('uploads/partner/'.$partner->image)); ?>" width="50px" height="50px"></td>
            <td><h6><?php echo e($partner->name); ?></h6></td>
            <td><h6><?php echo e($partner->url); ?></h6></td>
            <td><h6><?php echo e($partner->description); ?></h6></td>
            <td><a href="<?php echo e(url('admin/partner_delete/'.$partner->id)); ?>"><i class="btn btn-danger">Delete</i></a></td>
            <td><a href="<?php echo e(url('admin/partner_edit/'.$partner->id)); ?>"><i class="glyphicon glyphicon-edit"></i></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
            
        </table>
    </div>
    <?php
        Session::forget('message');
    ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>