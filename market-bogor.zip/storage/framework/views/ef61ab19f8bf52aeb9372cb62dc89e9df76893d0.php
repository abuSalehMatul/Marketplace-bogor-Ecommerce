
<?php $__env->startSection('title','Africa Directory List'); ?>
<?php $__env->startSection('content'); ?>
<div class="tp-page-head">
    <!-- page header -->
    <div class="container">
        <div class="row">
            <div class="col-md-offset-2 col-md-8">
                <div class="page-header text-center">
                    <h1>Download Africa Directory List</h1>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="tp-breadcrumb">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="active">Africa Directory List</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<div class="section-space80">
    <!-- Feature Blog Start -->
    <div class="container ">
        <div class="row">
            <div class="col-md-6">
                <h2>Sector's Wise Directory List</h2>
                <ul class="check-circle">
                     <?php $__currentLoopData = CommonClass::GetSector(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <li><a href="<?php echo e(url("sectors-directory/$crow->sector_slug")); ?>"><img src="<?php echo e(asset($crow->image)); ?>" width="20"> <?php echo e($crow->sector_name); ?></a></li>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="col-md-6">
                <h2>Country Wise Directory List</h2>
                <ul class="check-circle">
                     <?php $__currentLoopData = CommonClass::GetCountry(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <li><a href="<?php echo e(url("countries-directory/$crow->country_slug")); ?>"><img src="<?php echo e(asset($crow->country_flag)); ?>" width="20"> <?php echo e($crow->country_name); ?> Directory</a></li>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>