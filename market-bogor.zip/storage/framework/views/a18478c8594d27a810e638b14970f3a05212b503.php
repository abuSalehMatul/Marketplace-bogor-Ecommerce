<?php $__env->startSection('title','FAQ Edit'); ?>
<?php $__env->startPush('headerscript'); ?>
<link href="<?php echo e(asset('theme/plugins/summernote/summernote.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-page">
	<!-- Start content -->
	<div class="content">
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<div class="page-title-box">
						<h4 class="page-title">FAQ Edit</h4>
						<div class="clearfix"><a href="<?php echo e(route('buyerfaq.index')); ?>" class="pull-right btn btn-info btn-sm"><i class="fa fa-plus"></i>&nbsp;&nbsp;Back</a></div>
					</div>
				</div>
			</div>
			<!-- end row -->
			<div class="row">
				<div class="col-xs-12">
					<div class="card-box">
						<form action="<?php echo e(route('buyerfaq.update',$row->id)); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
							<?php echo csrf_field(); ?>
							<?php echo method_field('PUT'); ?>

							<div class="row form-group">
								<div class="col-sm-12">                 
									<h4 class="m-b-20 m-t-0 header-title"><b>Questions</b></h4>                  

									<textarea class="form-control summernote"  name="questions"><?php echo e(old('questions',$row->questions)); ?></textarea>

									<div class="text-danger"><?php echo e($errors->first('questions')); ?></div>
								</div>
							</div>
							<div class="row form-group">                

								<div class="col-sm-12">
									<label for="">Answers</label>
									<textarea name="answers" id="" class="form-control  summernote"><?php echo e(old('answers',$row->answers)); ?></textarea>
									<div class="text-danger"><?php echo e($errors->first('answers')); ?></div>                     
								</div>  

							</div>
							<div class="row form-group">
								
								<div class="col-md-12">
									<button class="btn btn-primary " type="submit">Save</button>
								</div>
							</div>	
						</form>				
					</div>
				</div>
			</div>
		</div> <!-- container -->
	</div> <!-- content -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('footerscript'); ?>
<script src="<?php echo e(asset('theme/plugins/summernote/summernote.min.js')); ?>"></script>
<script>
	jQuery(document).ready(function(){

		$('.summernote').summernote({
                    height: 180,                 // set editor height
                    minHeight: null,             // set minimum height of editor
                    maxHeight: null,             // set maximum height of editor
                    focus: false                 // set focus to editable area after initializing summernote
                });

	});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>