
<?php $__env->startPush('headerscript'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('webtheme/css/sidebar.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('title','Enquiry'); ?>
<?php $__env->startSection('content'); ?>
<?php 
$user=Auth::user();
$buyer=$user->buyer;
?>
<div class="tp-dashboard-head">
    <!-- page header -->
    <div class="container">
        <div class="row">
            <div class="col-md-12 profile-header">
                <div class="profile-pic col-md-2"><img src="images/profile-dashbaord.png" alt=""></div>
                <div class="profile-info col-md-9">
                    <h1 class="profile-title"><?php echo e($buyer->first_name); ?><small>Welcome Back memeber</small></h1>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /.page header -->

<div class="main-container">
    <div class="container">
        <div class="row">
            <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="col-md-9">
                <div class="row">
                    <div class="col-sm-12">
                        <h4>Manage Enquiry</h4>
                        <table class="table">
                            <thead>
                                <th>SN No</th>
                                <th>Name</th>
                                <th>Email ID</th>
                                <th>Phone No</th>
                                <th>Message</th>
                                <th>User Email</th>
                                <th>Date</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($row->name); ?></td>
                                    <td><?php echo e($row->email_id); ?></td>
                                    <td><?php echo e($row->phone); ?></td>
                                    <td><?php echo e($row->message); ?></td>
                                    <td><?php echo e($row->user->email); ?></td>
                                    <td><?php echo e(date('d M, Y', strtotime($row->created_at))); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('headerscript'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>