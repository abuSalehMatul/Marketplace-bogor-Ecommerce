<?php $__env->startSection('title','Manage Password'); ?>
<?php $__env->startPush('headerscript'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('webtheme/css/sidebar.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<?php 
$user=Auth::user();
$seller=$user->seller;
?>
<div class="tp-dashboard-head">
    <!-- page header -->
    <div class="container">
        <div class="row">
            <div class="col-md-12 profile-header">
                <div class="profile-pic col-md-2"><img src="images/profile-dashbaord.png" alt=""></div>
                <div class="profile-info col-md-9">
                    <h1 class="profile-title"><?php echo e($seller->first_name); ?><small>Welcome Back memeber</small></h1>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /.page header -->

<div class="main-container">
    <div class="container">
        <div class="row">
            <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="col-md-9">
                <div class="row">
                 <div class="well-box">
                    <form action="<?php echo e(url('seller/updatepassword')); ?>" method="post" >
                        <?php echo csrf_field(); ?>
                        <h2>Update Password</h2>
                        <!-- Text input-->
                        <?php if(Session::has('success_msg')): ?>
                        <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('success_msg')); ?></p>
                        <?php elseif(Session::has('danger_msg')): ?>
                        <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('danger_msg')); ?></p>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Old Password: <span>*</span></label>
                                    <input type="password" name="old" class="form-control" value="<?php echo e(old('old')); ?>" required="">
                                    <?php if($errors->has('old')): ?>
                                    <span class="text-danger">
                                        <strong><?php echo e($errors->first('old')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>New Password: <span>*</span></label>
                                    <input type="password" name="password" id="new_password" value="<?php echo e(old('password')); ?>" class="form-control" required="">
                                    <?php if($errors->has('password')): ?>
                                    <span class="text-danger">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Confirm Password: <span>*</span></label>
                                    <input type="password" name="password_confirmation" id="confirm_password" value="<?php echo e(old('password_confirmation')); ?>" class="form-control" required="">
                                    <?php if($errors->has('password_confirmation')): ?>
                                    <span class="text-danger">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <span id="password_error"></span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <button name="submit" class="pull-right btn btn-primary btn-sm">Save</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('footerscript'); ?>
<script>
    $(document).ready(function(){
        $("#new_password, #confirm_password").keyup(checkpassword);

    });

    function checkpassword(){
        var password=$("#new_password").val();
        var confirmpassword=$("#confirm_password").val();
        if(confirmpassword.length>0){
            if(password!=confirmpassword){
                $("#password_error").html("Password did not matched");
            }
            else{
                $("#password_error").html("Password matched");
            }
        }
    }
</script>
<script>
    function validateForm(){
        var password=document.getElementById("new_password").value;
        var confirmpassword=document.getElementById("confirm_password").value;
        if(password!=confirmpassword){
            $("#password_error").html("Password did not matched");
            return false;
        }
        else{
            return true;
        }
    }
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>