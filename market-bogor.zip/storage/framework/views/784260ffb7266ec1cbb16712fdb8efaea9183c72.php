<?php $__env->startSection('title','Featured Product'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-page">
    <div class="content">
        <div class="container">
           <table class="table table-striped">
                <thead>
                    <tr>
                    <th scope="col">Package</th>
                    <th scope="col">Product Unique Code</th>
                    <th scope="col">Product Name</th>
                    <th scope="col">Price</th>
                    <th scope="col" style="">Short Description</th>
                    <th scope="col">Post Type <button class="btn-info" style="float:left">Buy</button> <button class="btn-danger" style="float:right">Sell</button></th>
                    <th scope="col">Product Type <button class="btn-info" style="float:left">New</button> <button class="btn-danger" style="float:right">Old</button></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $product=App\Models\Product::all();
                        $plan_purchase_all=App\Models\SellerPurchasePlan::all();
                         $color=['#cdf2cd','#a4a9ad','#e2ceed','#fff5a0','#ccfffd','#20c1fc','#007ff7','#f79c00','#eff700','#00f7e2'];
                        $planIds=array();
                        foreach($plan_purchase_all as $plan_purchase_all){
                            array_push($planIds,$plan_purchase_all->id);
                        }
                        sort($planIds);

                    ?>
                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $seller=$product->seller_id;
                        $plan_purchase=App\Models\SellerPurchasePlan::where('seller_id',$seller)->first();
                       
                    ?>
                    <?php if($plan_purchase): ?>
                    <?php
                        $color_value=$plan_purchase->plan_id % 10;
                       
                        $plan=App\Models\SellerPlan::find($plan_purchase->id);
                    ?>
                    <tr style="background:<?php echo $color[$color_value] ?>;color:black">

                    <th scope="row"><button><?php echo e($plan->plan_name); ?></button></th>
                    <th scope="row"><?php echo e($product->unique_code); ?></th>
                    <td><?php echo e($product->product_name); ?></td>
                    <td><?php echo e($product->product_price); ?></td>
                    <td colspan="1" style=""><h6><?php echo e($product->short_description); ?></h6></td>
                    <?php if($product->post_type==1): ?>
                    <td>Buy</td>
                    <?php else: ?> 
                    <td>Sell</td>
                    <?php endif; ?>
                    <?php if($product->product_type==1): ?>
                    <td>New</td>
                    <?php else: ?> 
                     <td>Old</td>
                    <?php endif; ?>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>