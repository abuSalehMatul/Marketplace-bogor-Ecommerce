
<?php $__env->startSection('title','Join Our Community'); ?>
<?php $__env->startPush('headerscript'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('webtheme/css/sidebar.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('webtheme/css/social.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<?php 
$user=Auth::user();
$seller=$user->seller;
?>
<div class="tp-dashboard-head">
    <!-- page header -->
    <div class="container">
        <div class="row">
            <div class="col-md-12 profile-header">
                <div class="profile-pic col-md-2"><img src="images/profile-dashbaord.png" alt=""></div>
                <div class="profile-info col-md-9">
                    <h1 class="profile-title"><?php echo e($seller->first_name); ?><small>Welcome Back memeber</small></h1>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /.page header -->

<div class="main-container">
    <div class="container">
        <div class="row">
            <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="col-md-9">
                <div class="row">
                    <div class="col-md-4 form-group">
                        <a href="<?php echo e($row->fb); ?>" target="blank" class="btn btn-primary btn-block fb"><i class="fa fa-facebook-official"></i> Facebook</a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 form-group">
                        <a href="<?php echo e($row->twitter); ?>" target="blank" class="btn btn-primary btn-block twitter"><i class="fa fa-twitter"></i> Twitter</a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 form-group">
                        <a href="<?php echo e($row->whatsapp); ?>" target="blank" class="btn btn-primary btn-block whatsapp"><i class="fa  fa-whatsapp"></i> WhatsApp</a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 form-group">
                        <a href="<?php echo e($row->gplus); ?>" target="blank" class="btn btn-primary btn-block gplus"><i class="fa  fa-google-plus"></i> Google+</a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 form-group">
                        <a href="<?php echo e($row->instagram); ?>" target="blank" class="btn btn-primary btn-block instagram"><i class="fa  fa-instagram"></i> Instagram</a>
                    </div>
                </div>
                 
          </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>