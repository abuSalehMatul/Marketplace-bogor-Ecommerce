
<?php $__env->startSection('title',"$sellerproduct->product_name"); ?>
<?php $__env->startPush('headerscript'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="tp-page-head">
    <!-- page header -->
    <div class="container">
        <div class="row">
            <div class="col-md-offset-2 col-md-8">
                <div class="page-header text-center">
                    <h1><?php echo e($sellerproduct->product_name); ?></h1>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="section-space80">
    <!-- Feature Blog Start -->
    <div class="container">
        <div class="row">
            <div class="col-sm-9">
                <div class="vendor-box-list">
                    <!-- vendor list -->
                    <div class="row">
                        <div class="col-md-4 no-right-pd">
                            <div class="vendor-image">
                                <!-- venue pic -->
                                <a href="#"><img src="<?php echo e(asset($sellerproduct->featured_image)); ?>" alt="wedding venue" class="img-responsive"></a>
                            </div>
                        </div>
                        <!-- /.venue pic -->
                        <div class=" col-md-8 no-left-pd">
                            <!-- venue details -->
                            <div class="vendor-list-details">
                                <div class="caption">
                                    <!-- caption -->
                                    <h2><?php echo e($sellerproduct->product_name); ?></h2>
                                    <p>(Want to <?php echo e(($sellerproduct->post_type==1)?"Buy":"Sell"); ?>)</p>
                                    <p class="location"><i class="fa fa-map-marker"></i> <?php echo e($sellerproduct->seller->state.", ".$sellerproduct->seller->sellercountry->country_name); ?></p>
                                    <div class="rating"> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></div>
                                </div>
                                <!-- /.caption -->
                                <div class="vendor-price">
                                    <div class="price"><?php echo e(($sellerproduct->product_price)?"$".$sellerproduct->product_price:''); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="st-tabs">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation" class="active">
                            <a href="#myListing" title="Description" aria-controls="myListing" role="tab" data-toggle="tab" aria-expanded="true"> <i class="fa fa-list"></i><span class="tab-title"> Description</span></a>
                        </li>
                        <li role="presentation" class="">
                            <a href="#about" title="About Company" aria-controls="about" role="tab" data-toggle="tab" aria-expanded="true"> <i class="fa fa-list"></i><span class="tab-title"> About Company</span></a>
                        </li>
                        <li role="presentation" class=""> <a href="#makeEnquiry" title="Send Enquiry" aria-controls="makeEnquiry" role="tab" data-toggle="tab" aria-expanded="false"><i class="fa  fa-send"></i> <span class="tab-title"> Send Enquiry</span> </a> </li>
                    </ul>
                    <!-- Tab panes -->
                    <div class="tab-content">
                        <!-- tab content start-->
                        <div role="tabpanel" class="tab-pane fade active in" id="myListing">
                            <?php echo $sellerproduct->full_description; ?>

                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="about">
                            <?php echo $sellerproduct->seller->sellerprofile->profile_description; ?>

                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="makeEnquiry">
                            <div class="venue-details">
                                <?php if(auth()->guard()->guest()): ?>
                                <div class="col-sm-12">
                                    <h4 class="loginerror">First need to login/register</h4>
                                    <a href="<?php echo e(url('login')); ?>">Login</a>&nbsp;|&nbsp;
                                    <a href="<?php echo e(url('seller-register')); ?>">Register as Seller</a>&nbsp;|&nbsp;
                                    <a href="<?php echo e(url('buyer-register')); ?>">Register as Buyer</a>
                                </div>
                                <?php endif; ?>
                                <form id="makeenq" method="post"  action="<?php echo e(url("enquiry-for-seller/".$sellerproduct->seller->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <!-- Text input-->
                                    <div class="form-group">
                                        <label class="control-label" for="name-one">Name:<span class="required">*</span></label>
                                        <div class="">
                                            <input id="name-one" name="name" type="text" placeholder="Name" class="form-control input-md" required="">
                                            <div class="text-danger"><?php echo e($errors->first('name')); ?></div>
                                        </div>
                                    </div>
                                    <!-- Text input-->
                                    <div class="form-group">
                                        <label class="control-label" for="phone">Phone:<span class="required">*</span></label>
                                        <div class="">
                                            <input id="phone" name="phone" type="text" placeholder="Phone" class="form-control input-md" required=""></div>
                                            <div class="text-danger"><?php echo e($errors->first('phone')); ?></div>
                                        </div>
                                        <!-- Text input-->
                                        <div class="form-group">
                                            <label class="control-label" for="email-one">E-Mail:<span class="required">*</span></label>
                                            <div class="">
                                                <input id="email-one" name="email_id" type="text" placeholder="E-Mail" class="form-control input-md" required="">
                                                <div class="text-danger"><?php echo e($errors->first('email_id')); ?></div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label" for="email-one">Message<span class="required">*</span></label>
                                            <div class="">
                                                <textarea name="message" class="form-control"></textarea>
                                                <div class="text-danger"><?php echo e($errors->first('message')); ?></div>
                                            </div>
                                        </div>
                                        
                                        <div class="form-group">
                                            <button name="submit"  class="btn btn-primary btn-lg btn-block">Send Enquiry now</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.tab content start-->
                    <div class="row">
                        <div class="col-sm-12">f</div>
                    </div>
                    <div id="productcaro" class="owl-carousel owl-theme mycsutom">
                        <?php $__currentLoopData = $sellerproduct->seller->product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item testimonial-block">
                            <div class="couple-pic"><a href="<?php echo e(url("seller-product/$pro->product_slug/$pro->unique_code")); ?>"><img src="<?php echo e(asset($pro->featured_image)); ?>" alt="" class="img-responsive" ></a></div>

                            <div class="couple-info">
                                <div class="name"><a href="<?php echo e(url("seller-product/$pro->product_slug/$pro->unique_code")); ?>"><?php echo e($pro->product_name); ?></a></div>
                            </div>
                            <div class="bottom-sec">
                                <div class="name"><a  href="<?php echo e(url("seller-product/$pro->product_slug/$pro->unique_code")); ?>" class="btn btn-primary btn-sm" type="">Read More</a></div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="filter-sidebar">
                     <?php echo $__env->make('layout.sidebanner', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                 </div>
             </div>
         </div>
         <?php echo $__env->make('layout.bottomad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     </div>
 </div>
<!-- Go to www.addthis.com/dashboard to customize your tools --> <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5c3ca221186af4ba"></script>
 <?php $__env->stopSection(); ?>
 <?php $__env->startPush('footerscript'); ?>
 <script>
   $(".mycsutom").owlCarousel({
      
      navigation : false, // Show next and prev buttons
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem:false,
      autoPlay: 5000,
      items : 4,
  });
</script>
<script>
 $('#makeenq').on('submit', function() {
    var AuthUser = "<?php echo e((Auth::user()) ? Auth::user() : null); ?>";
    if(AuthUser){
        return true;
    }else{
        $(".loginerror").addClass('text-danger')
        alert("First need to login/register");
        return false;
    }   
});

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>