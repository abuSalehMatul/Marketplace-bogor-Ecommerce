<?php $__env->startSection('title','Fronted_Control'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-page">
  <div class="content">
    <div class="container">
        <table class="table table-striped">
            <thead>
                <tr>
                <th scope="col">Plan Id</th>
                <th scope="col">Plan name</th>
                <th scope="col">Take Images</th>
                <th scope="col">Priority</th>
               
                </tr>
            </thead>
            <?php
                $plan_priority=App\Seller_plan_priority::all();
            ?>
            <?php if($plan_priority): ?>
            <tbody>
                <?php $__currentLoopData = $plan_priority; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan_priority): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <th scope="row"><?php echo e($plan_priority->seller_plan_id); ?></th>
                <?php
                    $plan=App\Models\SellerPlan::find($plan_priority->seller_plan_id);
                ?>
                <th scope="row"><?php echo e($plan->plan_name); ?></th>
                <td><?php echo e($plan_priority->array_size); ?></td>
                <td><?php echo e($plan_priority->priority); ?></td>
               
                </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <?php endif; ?>
        </table>
        <a href="<?php echo e(url('admin/set_new_plan_frontend')); ?>" class="btn btn-info">Set New Plan</a>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>