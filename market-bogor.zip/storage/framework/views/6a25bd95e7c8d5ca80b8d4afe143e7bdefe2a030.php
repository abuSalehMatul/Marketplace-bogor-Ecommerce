<?php $__env->startSection('title','Category'); ?>
<?php $__env->startSection('content'); ?>

<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">


            <div class="row">
                <div class="col-xs-12">
                    <div class="page-title-box">
                        <h4 class="page-title">Edit Category</h4>
                         <div class="clearfix"><a href="<?php echo e(route('category.index')); ?>" class="pull-right btn btn-info btn-sm"><i class="fa fa-backward"></i> Back</a></div>
                    </div>
                </div>
            </div>
            <!-- end row -->
            <div class="row">
                <div class="col-xs-12">
                    <div class="card-box">
                        <?php echo e(Form::open(array('route' => array('category.update', $row->id),'class' =>'form-horizontal','method' =>'PATCH','files'=>true))); ?>

                        <div class="row">
                            <div class="col-sm-6">
                              <div class="row">
                               <div class="form-group">
                                   <div class="col-sm-12">
                                       <label for="">Category Name</label>
                                       <input type="text" name="category_name" class="form-control" required="" value="<?php echo e(old('category_name',$row->category_name)); ?>">
                                       <div class="text-danger"><?php echo e($errors->first('category_name')); ?></div>
                                   </div>
                               </div>
                           </div>
                           <div class="row">
                               <div class="form-group">
                                   <div class="col-sm-12">
                                       <label for="">Thumb Image</label>
                                       <input type="file" name="thumb_img" class="form-control" onchange="loadFile(event, 'logos')" accept="image/*">
                                       <div class="text-danger"><?php echo e($errors->first('thumb_img')); ?></div>
                                   </div>

                               </div>
                           </div>

                           <div class="row">
                            <div class="form-group">
                                <div class="col-md-12">
                                    <button class="btn btn-primary btn-sm" type="submit">Save</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <img src="<?php echo e(asset($row->thumb_img)); ?>" alt="" id="logos" >
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>


</div> <!-- container -->

</div> <!-- content -->

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('footerscript'); ?>
<script>
    var loadFile = function (event, imgid) {
        var output = document.getElementById(imgid);
        output.src = URL.createObjectURL(event.target.files[0]);
    };
</script>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>