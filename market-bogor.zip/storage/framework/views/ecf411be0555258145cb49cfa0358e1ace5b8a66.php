<?php $__env->startSection('title','Seller Help'); ?>
<?php $__env->startSection('content'); ?>
<style>
.nav-tabs a{
    color#000 !important;
}
</style>

<div class="tp-page-head">
    <!-- page header -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page-header">
                    <h1>Seller Help</h1>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="tp-breadcrumb">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li>Seller Help</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<div class="main-container">
    <div class="container">
        <div class="row">
            <div class="col-md-3 side-nav" id="leftCol">
                <div class="hide-side">
                    <ul class="listnone nav" id="sidebar">
                         <li class="active"><a href="<?php echo e(url('help-for-seller')); ?>">help</a>
                        <li ><a href="<?php echo e(url('sallersafety')); ?>">Safety</a></li>
                        <li><a href="<?php echo e(url('faq-for-seller')); ?>">FAQ</a></li>
                       
                        </ul>
                    </div>
                </div>
                <div class="col-md-9 content-right">
                    <div class="aboutus" id="aboutus">
                        <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h2><a href="#" class="title">Help for Seller</a></h2>
                        <p class="lead"><?php echo e($r->full_description); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
            </div>

        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>