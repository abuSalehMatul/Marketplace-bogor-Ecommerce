<?php $__env->startPush('headerscript'); ?>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
<div class="tp-page-head">
    <!-- page header -->
    <div class="container">
        <div class="row">
            <div class="col-md-offset-2 col-md-8">
                <div class="page-header text-center">
                    <h1>Download <?php echo e($sector->sector_name); ?> Directory</h1>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="tp-breadcrumb">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <ol class="breadcrumb">
                        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li class="active"><?php echo e($sector->sector_name); ?> Directory</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
<div class="section-space80">
    <!-- Feature Blog Start -->
    <div class="container ">
        <div class="row">
            <div class="col-md-3 left-sidebar">
                <div class="col-md-12 widget widget-category">
                    <!-- widget -->
                    <div class="well-box">
                        <h2 class="widget-title">Sectors</h2>
                        <ul class="listnone angle-double-right sidebarlist">
                            <?php $__currentLoopData = CommonClass::GetSector(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catrow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(url("sectors-directory/$catrow->sector_slug")); ?>"><?php echo e($catrow->sector_name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <img src="<?php echo e(asset('webtheme/images/banner/2.jpg')); ?>" class="img-thumbnail" alt="">
                </div>
            </div>
            <div class="col-sm-9 cardbox">
                <?php if($data): ?>
                <?php if(!empty(Session::get('sectordata'))): ?>
                <div class="alert alert-success" role="alert">
                    <strong>Thank you ! </strong> <a href="<?php echo e(url("downalodfile-sector")); ?>">Click here for Download Directory</a>. </div>
                <?php endif; ?>
                <form action="<?php echo e(url("download-sector-directory/$data->id")); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-sm-4">
                        <img src="<?php echo e(asset($data->featured_image)); ?>" class="img-responsive">
                    </div>
                    <div class="col-sm-8">
                        <h1><?php echo e($data->title); ?></h1>
                        <ul class="check-circle">
                            <?php $__currentLoopData = $data->sectorfeature; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($row->feature_name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="submit" class="btn btn-default btn-lg">Buy Now</button> <b>@ US $<?php echo e($data->price); ?></b>


                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-sm-12">
                         <?php echo $data->description; ?>

                    </div>
                </div>
                <div class="row">
                    <div class="cols-sm-12 download-box text-center">
                        <h4>Download Now</h4>
                        <div class=""><button type="submit" class="btn btn-default btn-lg">Buy Now @ US $<?php echo e($data->price); ?></button></div>
                    </div>
                </div>
                </form>
                 <?php else: ?>
                <h1 class="text-danger">Sorry no any data for now</h1>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<!-- Go to www.addthis.com/dashboard to customize your tools --> <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5c3ca221186af4ba"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('footerscript'); ?>
<script src="<?php echo e(asset('custom/wizard.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>