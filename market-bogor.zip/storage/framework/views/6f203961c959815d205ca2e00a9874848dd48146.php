
<?php $__env->startSection('title','Buyer List'); ?>
<?php $__env->startSection('content'); ?>

<div class="content-page">
  <!-- Start content -->
  <div class="content">
    <div class="container">
      <div class="row">
        <div class="col-xs-12">
          <div class="page-title-box">
            <h4 class="page-title">Edit Seller</h4>
            <div class="clearfix"><a href="<?php echo e(route('sellerlist.index')); ?>" class="pull-right btn btn-info btn-sm"><i class="fa fa-backward"></i> Back</a></div>
          </div>
        </div>
      </div>
      <!-- end row -->
      <div class="row">
        <div class="col-sm-12">
          <div class="card-box">
            <?php echo e(Form::open(array('route' => array('buyerlist.update', $row->id),'class' =>'form-horizontal','method' =>'PATCH','files'=>true))); ?>

            <div class="row">
              <div class="form-group">
                <div class="col-sm-6">
                  <label for="">First Name</label>
                  <input type="text" name="first_name" class="form-control" required="" value="<?php echo e(old('first_name',$row->first_name)); ?>">
                  <div class="text-danger"><?php echo e($errors->first('first_name')); ?></div>
                </div>
                <div class="col-sm-6">
                  <label for="">Last Name</label>
                  <input type="text" name="last_name" value="<?php echo e(old('last_name',$row->last_name)); ?>" class="form-control" placeholder="Last Name" required="">
                  <span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="form-group">
                <div class="col-sm-6">
                  <label>Instant Type: <span>*</span></label>
                  <?php echo Form::select('instant_type',['1'=>'WhatsApp','2'=>'Skype','3'=>'WeChat'], old('instant_type',$row->instant_type),  ['class'=>'form-control ', 'required'=>'']); ?>

                  <span class="text-danger"><?php echo e($errors->first('instant_type')); ?></span>
                  <span class="text-danger"><?php echo e($errors->first('instant_type')); ?></span>
                </div>
                <div class="col-sm-6">
                  <label>Instant ID: <span>*</span></label>
                  <input type="text" name="instant_id" value="<?php echo e(old('instant_id',$row->instant_id)); ?>" class="form-control" placeholder="Enter Instant ID" required>
                  <span class="text-danger"><?php echo e($errors->first('instant_id')); ?></span>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="form-group">
                <div class="col-sm-6">
                  <label>Company Name: <span>*</span></label>
                  <input type="text" name="company_name" value="<?php echo e(old('company_name',$row->company_name)); ?>" class="form-control" placeholder="Enter Company Name (if any)" required="">
                  <span class="text-danger"><?php echo e($errors->first('company_name')); ?></span>
                </div>
                <div class="col-sm-6">
                  <label>Business Sector: <span>*</span></label>
                  <?php echo Form::select('business_sector',[''=>'-Business Sector-']+ CommonClass::CategoryList(), old('business_sector',$row->business_sector),  ['class'=>'form-control','required'=>'']); ?>

                  <span class="text-danger"><?php echo e($errors->first('business_sector')); ?></span>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="form-group">
                <div class="col-sm-6">
                  <label>Status of Company: <span>*</span></label>
                  <?php echo Form::select('company_status',[''=>'Status of Company','1'=>'Agent','2'=>'End User','3'=>'Reseller'], old('company_status',$row->company_status),  ['class'=>'form-control','required'=>'']); ?>


                  <span class="text-danger"><?php echo e($errors->first('company_status')); ?></span>
                </div>
                <div class="col-sm-6">
                  <label>Designation: <span>*</span></label>
                  <input type="text" name="designation" value="<?php echo e(old('designation',$row->degignation)); ?>" class="form-control" placeholder="Your Designation (if any)">
                  <span class="text-danger"><?php echo e($errors->first('designation')); ?></span>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="form-group">
                <div class="col-sm-6">
                  <label>Contact Number: <span>*</span></label>
                  <input type="text" name="contact_number" value="<?php echo e(old('contact_number',$row->contact_number)); ?>" class="form-control" required="" placeholder="Contact Number">
                  <span class="text-danger"><?php echo e($errors->first('contact_number')); ?></span>
                </div>
                <div class="col-sm-6">
                  <label>Website: <span>*</span></label>
                  <input type="text" name="website" value="<?php echo e(old('website',$row->website)); ?>" class="form-control" placeholder="Website (eg: www.domain.com)">
                  <span class="text-danger"><?php echo e($errors->first('website')); ?></span>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="form-group">
                <div class="col-sm-6">
                  <label>Address Line1: <span>*</span></label>
                  <input type="text" name="address1" value="<?php echo e(old('address1',$row->address1)); ?>" class="form-control" required="" placeholder="Address Line1">
                  <span class="text-danger"><?php echo e($errors->first('address1')); ?></span>
                </div>
                <div class="col-sm-6">
                  <label>Address Line2: <span>*</span></label>
                  <input type="text" name="address2" value="<?php echo e(old('address2',$row->address2)); ?>" class="form-control" required="" placeholder="Address Line2">
                  <span class="text-danger"><?php echo e($errors->first('address2')); ?></span>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="form-group">
                <div class="col-sm-6">
                  <label>City: <span>*</span></label>
                  <input type="text" name="city" value="<?php echo e(old('city',$row->city)); ?>" class="form-control" required="" placeholder="City">
                  <span class="text-danger"><?php echo e($errors->first('city')); ?></span>
                </div>
                <div class="col-sm-6">
                  <label>State: <span>*</span></label>
                  <input type="text" name="state" value="<?php echo e(old('state',$row->state)); ?>" class="form-control" required="" placeholder="State">
                  <span class="text-danger"><?php echo e($errors->first('state')); ?></span>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="form-group">
                <div class="col-sm-6">
                  <label>Postal/Zip code: <span>*</span></label>
                  <input type="text" name="postal" value="<?php echo e(old('postal',$row->postal)); ?>" class="form-control" required="" placeholder="Postal/Zip code">
                  <span class="text-danger"><?php echo e($errors->first('postal')); ?></span>
                </div>
                <div class="col-sm-6">
                  <label>Country: <span>*</span></label>
                  <?php echo Form::select('country',[''=>'-Select Country-']+ CommonClass::CountryList(), old('country',$row->country), ['class'=>'form-control','required'=>'']); ?>

                  <span class="text-danger"><?php echo e($errors->first('country')); ?></span>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="form-group">
                <div class="col-sm-6">
                  <label>Sell In: <span>*</span> </label>
                  <label class="radio-inline">
                    <input type="radio" name="sell_in" id="Radios1" value="1" <?php echo e(($row->sell_in==1)?"checked":''); ?> required="" >
                    Africa
                  </label>
                  <label class="radio-inline">
                    <input type="radio" name="sell_in" id="Radios2" value="2" <?php echo e(($row->sell_in==2)?"checked":''); ?> required="">
                    Global
                  </label>
                  <span class="text-danger"><?php echo e($errors->first('sell_in')); ?></span>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="form-group">
                <div class="col-md-12">
                  <button class="pull-right btn btn-primary btn-sm" type="submit">Save</button>
                </div>
              </div>
            </div>
            <?php echo Form::close(); ?>

          </div>

        </div>
      </div>
    </div>
  </div> <!-- container -->
</div> <!-- content -->
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>