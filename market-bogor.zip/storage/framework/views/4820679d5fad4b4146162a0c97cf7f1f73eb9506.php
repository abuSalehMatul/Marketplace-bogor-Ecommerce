<?php $__env->startSection('title','User List'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-page">
	<div class="content">
		<?php
			$user=App\User::all()->sortByDesc('created_at');
		?>
		<table class="table table-striped">
			<thead class="thead-dark">
				<tr>
					<th scope="col">User Name</th>
					<th scope="col">User Id</th>
					<th scope="col">Email</th>
					<th scope="col">Buyer</th>
					<th scope="col">Seller</th>
					<th scope="col">Registration Date/Time</th>
				</tr>
			</thead>
			<tbody>
			<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php
				$seller=App\Models\Seller::where('user_id',$user->id)->count();
				$buyer=App\Models\Buyer::where('user_id',$user->id)->count();
			?>
			<tr>
				<td><?php echo e($user->name); ?></td>
				<td><?php echo e($user->id); ?></td>
				<td><h6><?php echo e($user->email); ?></h6></td>
				<?php if($buyer > 0): ?>
				<td><h6><i class="fas fa-check-circle"></i></h6></td>
				<?php else: ?>
				<td><h6></h6></td>
				<?php endif; ?>
				<?php if($seller > 0): ?>
				<td><h6><i class="fas fa-check-circle"></i></h6></td>
				<?php else: ?> 
				<td><h6></h6></td>
				<?php endif; ?>
				<td><h6><?php echo e($user->created_at); ?></h6></td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		 	<tbody>
	</table>
	</div>
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>