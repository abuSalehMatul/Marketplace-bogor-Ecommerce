<?php $__env->startSection('title','Crate'); ?>
<?php $__env->startPush('headerscript'); ?>
<link href="<?php echo e(asset('theme/plugins/summernote/summernote.css')); ?>" rel="stylesheet" />

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-page">
	<!-- Start content -->
	<div class="content">
		<div class="container">


			<div class="row">
				<div class="col-xs-12">
					<div class="page-title-box">
						<h4 class="page-title">Crate</h4>
						<div class="clearfix"><a href="<?php echo e(route('sellerhelp.index')); ?>" class="pull-right btn btn-info btn-sm"><i class="fa fa-plus"></i>&nbsp;&nbsp;Back</a></div>
					</div>
				</div>
			</div>
			<!-- end row -->
			<div class="row">
				<div class="col-xs-12">
					<div class="card-box">
						<form action="<?php echo e(route('sellerhelp.store')); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
							<?php echo csrf_field(); ?>

							<div class="row form-group">
								<div class="col-sm-6">
									<label for="">Title</label>
									<input type="text" name="title" class="form-control" required="" value="<?php echo e(old('title')); ?>">
									<div class="text-danger"><?php echo e($errors->first('title')); ?></div>             
								</div>
								<div class="col-sm-6">
									<label for="">Icon Class</label>
									<input type="text" name="icon_class" class="form-control" required="" value="<?php echo e(old('icon_class')); ?>">
									<div class="text-danger"><?php echo e($errors->first('icon_class')); ?></div>             
								</div>

							</div>

							<div class="row form-group">
								<div class="col-sm-12">                 
									<h4 class="m-b-20 m-t-0 header-title"><b>Full Description</b></h4>                  

									<textarea class="form-control summernote"  name="full_description"><?php echo e(old('full_description')); ?></textarea>

									<div class="text-danger"><?php echo e($errors->first('full_description')); ?></div>
								</div>
							</div>
							<div class="row form-group">                

								<div class="col-sm-12">
									<label for="">Short Description</label>
									<textarea name="short_description" id="" class="form-control" cols="30" rows="2" placeholder="Short Description .."></textarea>
									<div class="text-danger"><?php echo e($errors->first('short_description')); ?></div>                     
								</div>  

							</div>
							<div class="row form-group">
								
								<div class="col-md-12">
									<button class="btn btn-primary " type="submit">Save</button>
								</div>
							</div>	
							</form>				
						</div>
					</div>
				</div>


			</div> <!-- container -->

		</div> <!-- content -->

	</div>
	<?php $__env->stopSection(); ?>

	<?php $__env->startPush('footerscript'); ?>

	<script src="<?php echo e(asset('theme/plugins/summernote/summernote.min.js')); ?>"></script>
	<script>
		jQuery(document).ready(function(){

			$('.summernote').summernote({
                    height: 180,                 // set editor height
                    minHeight: null,             // set minimum height of editor
                    maxHeight: null,             // set maximum height of editor
                    focus: false                 // set focus to editable area after initializing summernote
                });

		});
	</script>
	<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>