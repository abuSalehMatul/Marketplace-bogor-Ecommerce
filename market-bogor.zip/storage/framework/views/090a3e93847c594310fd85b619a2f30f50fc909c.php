<?php $__env->startSection('content'); ?>
<style>
.nav-tabs a{
    color#000 !important;
}
</style>
<?php ($row=CommonClass::WebsiteProfile()); ?>
<div class="tp-page-head">
    <!-- page header -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page-header">
                    <h1>Contact us</h1>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="tp-breadcrumb">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li>Contact Us</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<div class="main-container">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="well-box">
                    <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo Session::get('success'); ?>

                    </div>
                    <?php endif; ?>
                    <p>Please fill out the form below and we will get back to you as soon as possible.</p>
                    <form action="<?php echo e(url('enquiry')); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <!-- Text input-->
                        <div class="form-group">
                            <label class="control-label" for="first">First Name <span class="required">*</span></label>
                            <input id="first" name="first" type="text" placeholder="First Name" value="<?php echo e(old('first')); ?>" class="form-control input-md" required>
                            <span class="text-danger"><?php echo e($errors->first('first')); ?></span>
                        </div>
                        <!-- Text input-->
                        <div class="form-group">
                            <label class=" control-label" for="lastname">Last Name <span class="required">*</span></label>
                            <div class=" ">
                                <input id="lastname" name="lastname" type="text" placeholder="Last name" value="<?php echo e(old('lastname')); ?>" class="form-control input-md" required>
                            </div>
                            <span class="text-danger"><?php echo e($errors->first('lastname')); ?></span>
                        </div>
                        <!-- Text input-->
                        <div class="form-group">
                            <label class=" control-label" for="email">E-Mail <span class="required">*</span></label>
                            <input id="email" value="<?php echo e(old('email')); ?>" name="email" type="text" placeholder="E-Mail" class="form-control input-md" required>
                            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                        </div>
                        <!-- Text input-->
                        <div class="form-group">
                            <label class=" control-label" for="phone">Phone <span class="required">*</span></label>
                            <input id="phone" value="<?php echo e(old('phone')); ?>" name="phone" type="text" placeholder="Phone" class="form-control input-md" required>
                            <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                        </div>
                        <!-- Textarea -->
                        <div class="form-group">
                            <label class="  control-label" for="message">Message</label>
                            <textarea class="form-control" maxlength="500" rows="6" id="message" name="message" placeholder="Write Your Message"><?php echo e(old('message')); ?></textarea>
                            <span class="text-danger"><?php echo e($errors->first('message')); ?></span>
                        </div>
                        <!-- Button -->
                        <div class="form-group">
                            <button id="submit" name="submit" class="btn btn-primary btn-lg">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-6 contact-info">
                <div class="well-box">
                    <ul class="listnone">
                        <li class="address">
                            <h2><i class="fa fa-map-marker"></i>Location</h2>
                            <p><?php echo e($row->business_address); ?></p>
                        </li>
                        <li class="email">
                            <h2><i class="fa fa-envelope"></i>E-Mail</h2>
                            <p><?php echo e($row->email_id); ?></p>
                        </li>
                        <li class="call">
                            <h2><i class="fa fa-phone"></i>Contact</h2>
                            <p><?php echo e($row->phone_no); ?></p>
                        </li>
                    </ul>
                </div>
                <div class="social-icon">
                    <h2>Find us on Social Media</h2>
                    <ul>
                        <li><a href="<?php echo e($row->fb_url); ?>" target="_blank"><i class="fa fa-facebook-square"></i></a></li>
                        <li><a href="<?php echo e($row->twitter_url); ?>" target="_blank"><i class="fa fa-twitter-square"></i></a></li>
                        <li><a href="<?php echo e($row->gplus_url); ?>" target="_blank"><i class="fa fa-google-plus-square"></i></a></li>
                        <li><a href="<?php echo e($row->inst_url); ?>" target="_blank"><i class="fa fa-instagram"></i></a></li>
                        <li><a href="<?php echo e($row->youtube_url); ?>" target="_blank"><i class="fa fa-youtube"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>