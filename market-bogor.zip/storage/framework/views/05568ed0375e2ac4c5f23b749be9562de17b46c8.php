<?php $__env->startSection('title','User Activity List'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-page">
	<div class="content">
        <?php
            $buyer_trafic=App\Models\BuyerTraffic::all()->sortByDesc('created_at');
        ?>
        <div class="card">
        <h5 class="card-header text-center text-info">Buyer Activity</h5>
        </div>
        <div class="card-body"  style="height:400px;overflow-y:scroll">
           <table class="table table-striped" >
                <thead>
                    <tr>
                    <th scope="col">Name of the Buyer</th>
                    <th scope="col">Visited</th>
                    <th scope="col">Date/Time</th>
                   
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $buyer_trafic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyer_trafic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $user_id=$buyer_trafic->buyer_id;
                        $user=App\User::find($user_id);
                    ?>
                    <?php if($user): ?>
                    <tr>
                    <th scope="row"><?php echo e($user->name); ?></th>
                    <td><?php echo e($buyer_trafic->page_name); ?></td>
                    <td><?php echo e($buyer_trafic->created_at); ?></td>
                   
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
	<div class="content">
        <?php
            $seller_trafic=App\Models\SellerTraffic::all()->sortByDesc('created_at');
        ?>
        <div class="card">
        <h5 class="card-header text-center text-info">Seller Activity</h5>
        </div>
        <div class="card-body"  style="height:400px;overflow-y:scroll">
           <table class="table table-striped" >
                <thead>
                    <tr>
                    <th scope="col">Name of the Seller</th>
                    <th scope="col">Visited</th>
                    <th scope="col">Date/Time</th>
                   
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $seller_trafic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller_trafic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $user_id=$seller_trafic->seller_id;
                        $user=App\User::find($user_id);
                    ?>
                    <?php if($user): ?>
                    <tr>
                    <th scope="row"><?php echo e($user->name); ?></th>
                    <td><?php echo e($seller_trafic->page_name); ?></td>
                    <td><?php echo e($seller_trafic->created_at); ?></td>
                   
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
	


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>